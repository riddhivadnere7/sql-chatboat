﻿from setuptools import setup
setup(name='askql', packages=['src'])
