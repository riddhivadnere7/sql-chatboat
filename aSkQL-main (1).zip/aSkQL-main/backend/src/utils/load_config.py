import os
from dotenv import load_dotenv
import yaml
from pyprojroot import here
import shutil
import google.generativeai as genai
from langchain_google_genai import ChatGoogleGenerativeAI

print("Environment variables are loaded:", load_dotenv())

class LoadConfig:
    def __init__(self) -> None:
        with open(here("configs/app_config.yml")) as cfg:
            app_config = yaml.load(cfg, Loader=yaml.FullLoader)

        self.load_directories(app_config=app_config)
        self.load_llm_configs(app_config=app_config)
        self.load_gemini_model()

    def load_directories(self, app_config):
        self.uploaded_files_sqldb_directory = str(here(
            app_config["directories"]["uploaded_files_sqldb_directory"]))

    def load_llm_configs(self, app_config):
        self.model_name = "gemini-1.5-pro"
        self.temperature = app_config["llm_config"]["temperature"]

    def load_gemini_model(self):
        genai.configure(api_key=os.getenv("GOOGLE_API_KEY"))
        self.langchain_llm = ChatGoogleGenerativeAI(
            model=self.model_name,
            temperature=self.temperature,
            convert_system_message_to_human=True
        )