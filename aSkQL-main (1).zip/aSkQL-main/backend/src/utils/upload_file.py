
import os
import pandas as pd
from sqlalchemy import create_engine
from utils.load_config import LoadConfig

APPCFG = LoadConfig()

class ProcessFiles:
    def __init__(self, files_dir: list, chatbot: list):
        self.files_dir = files_dir
        self.chatbot = chatbot
        self.db_path = f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}"
        
    def _process_uploaded_files(self) -> tuple:
        os.makedirs(os.path.dirname(APPCFG.uploaded_files_sqldb_directory), exist_ok=True)
        
        for file_dir in self.files_dir:
            try:
                file_name = os.path.splitext(os.path.basename(file_dir))[0]
                if file_dir.endswith('.csv'):
                    df = pd.read_csv(file_dir)
                elif file_dir.endswith('.xlsx'):
                    df = pd.read_excel(file_dir)
                else:
                    continue
                
                engine = create_engine(self.db_path)
                df.to_sql(file_name, engine, if_exists='replace', index=False)
                
                self.chatbot.append((f"Uploaded {os.path.basename(file_dir)}", 
                                   f"Processed as table '{file_name}'"))
            except Exception as e:
                self.chatbot.append((f"Uploaded {os.path.basename(file_dir)}", 
                                   f"Error processing file: {str(e)}"))
        
        return "", self.chatbot

    def run(self):
        return self._process_uploaded_files()