# import os
# import re
# from typing import List, Tuple
# from utils.load_config import LoadConfig
# from langchain_community.utilities import SQLDatabase
# from langchain.chains import create_sql_query_chain
# from langchain_community.tools.sql_database.tool import QuerySQLDataBaseTool
# from sqlalchemy import create_engine

# APPCFG = LoadConfig()

# class ChatBot:
#     @staticmethod
#     def _format_sql_response(response: str) -> str:
#         """Format SQL response to clean up output"""
#         response = response.replace("```sql", "").replace("```", "").strip()
        
#         if "SQL Query:" in response and "Explanation:" in response:
#             parts = response.split("SQL Query:", 1)[1].split("Explanation:", 1)
#             query = parts[0].strip()
#             explanation = parts[1].strip()
#             return f"SQL Query:\n{query}\n\nExplanation:\n{explanation}"
#         return response

#     @staticmethod
#     def _clean_sql_result(result: str) -> str:
#         """Clean up SQL result to display just the number"""
#         match = re.search(r'\((\d+)\)', result)
#         return match.group(1) if match else result

#     @staticmethod
#     def respond(chatbot: List, message: str, app_functionality: str, sql_dialect: str = "Standard") -> Tuple[str, List]:
#         # Basic greetings handling
#         lower_msg = message.lower().strip()
#         greetings = {
#             'hello': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
#             'hi': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
#             'hey': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
#             'thanks': "You're welcome! **AskQL** is always happy to assist with your data needs. Let me know if you have more questions!",
#             'thank you': "You're welcome! **AskQL** is always happy to assist with your data needs. Let me know if you have more questions!",
#             'bye': "Goodbye from **AskQL**! Remember - when you need SQL help, just ask QL!",
#             'what is askql': "I'm **AskQL** - your smart SQL assistant!\nFeatures:\n- Generate optimized SQL queries\n- Explain queries in simple terms\n- Support multiple SQL dialects\n- Analyze your data files\n\nTry asking me anything about SQL!",
#             'who are you': "I'm **AskQL** - your smart SQL assistant!\nFeatures:\n- Generate optimized SQL queries\n- Explain queries in simple terms\n- Support multiple SQL dialects\n- Analyze your data files\n\nTry asking me anything about SQL!"
#         }
        
#         if lower_msg in greetings:
#             chatbot.append((message, greetings[lower_msg]))
#             return "", chatbot

#         # Add context from previous messages
#         chat_history = "\nPrevious conversation:\n"
#         for user_msg, bot_resp in chatbot[-5:]:  # Only keep last 5 exchanges for context
#             chat_history += f"User: {user_msg}\nAssistant: {bot_resp}\n"

#         # SQL Generation
#         if app_functionality == "SQL Chat":
#             try:
#                 dialect_prompt = {
#                     "Trino": "Generate SQL in Trino dialect. Follow these best practices: "
#                              "Use double quotes for identifiers, Prefer array_agg() over GROUP_CONCAT(), "
#                              "approx_distinct() instead of COUNT(DISTINCT) when working with large datasets,"
#                              "Prefer FILTER(WHERE condition) over CASE WHEN inside aggregation functions for better readability,"
#                              "When using LIMIT, consider ordering the results explicitly to avoid non-deterministic behavior,"
#                              "Use CAST() instead of :: for type conversions,"
#                              "Prefer ANSI JOIN syntax (INNER JOIN, LEFT JOIN, etc.) instead of implicit joins,"
#                              "Always qualify column names when joining multiple tables to prevent ambiguity,"
#                              "For window functions, explicitly define the partition and order clauses (e.g., PARTITION BY column ORDER BY column),"
#                              "Avoid using SELECT * in production queries; explicitly specify required columns for efficiency,"
#                              "Use UNNEST(array_column) instead of EXPLODE() to flatten arrays,"
#                              "Combine CROSS JOIN UNNEST(array_column) when dealing with multiple arrays,"
#                              "Prefer array_join() for converting arrays to delimited strings.",
                             
#                     "Spark": "Generate SQL in Spark SQL dialect. Follow these best practices: " 
#                              "Use backticks (`) for identifiers instead of double quotes," 
#                              "Prefer collect_list() over GROUP_CONCAT()," 
#                              "Use approx_count_distinct() instead of COUNT(DISTINCT) for performance optimization on large datasets,"  
#                              "When filtering NULL values, use IS NOT NULL instead of <> NULL," 
#                              "Always specify the column alias explicitly when using aggregate functions,"  
#                              "Use IF() or CASE WHEN instead of Trino's FILTER(WHERE condition),"  
#                              "Spark supports Common Table Expressions (CTEs) (WITH clause), so use them for readability in complex queries," 
#                              "Use sort_array() when sorting arrays instead of manually ordering elements in collect_list(),"  
#                              "Always use DISTRIBUTE BY or SORT BY for performance tuning in large-scale aggregations,"  
#                              "When dealing with JSON data, use get_json_object() or json_tuple() instead of ->>,"  
#                              "Use EXPLODE(array_column) instead of UNNEST() to flatten arrays,"  
#                              "Prefer posexplode() when the index position of elements is needed,"  
#                              "Use concat_ws() for converting arrays into comma-separated strings."  
#                 }.get(sql_dialect, "")
                
#                 prompt = f"""You are a SQL expert assistant. For this request:
#                 {chat_history}
#                 Current request: {message}

#                 {dialect_prompt}
#                 1. Generate the appropriate SQL query
#                 2. Explain what the query does
#                 3. Consider the previous conversation context when appropriate

#                 Format your response as:
#                 SQL Query: [query here]
#                 Explanation: [explanation here]
#                 """
                
#                 response = APPCFG.langchain_llm.invoke(prompt).content
#                 formatted_response = ChatBot._format_sql_response(response)
#                 chatbot.append((message, formatted_response))
#                 return "", chatbot
            
#             except Exception as e:
#                 chatbot.append((message, f"Error: {str(e)}"))
#                 return "", chatbot
        
#         # File Analysis
#         elif app_functionality == "File Analysis":
#             if os.path.exists(APPCFG.uploaded_files_sqldb_directory):
#                 try:
#                     engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
#                     db = SQLDatabase(engine)
                    
#                     # Generate SQL query with dialect consideration and chat history
#                     question_with_history = f"{chat_history}\nCurrent question: {message}"
#                     base_query = create_sql_query_chain(APPCFG.langchain_llm, db).invoke({"question": question_with_history})
#                     query = base_query.replace("SQLQuery:", "").strip()
                    
#                     # Convert to selected dialect if needed
#                     if sql_dialect in ["Trino", "Spark"]:
#                         conversion_prompt = f"""Convert this SQL to {sql_dialect} dialect:
#                         {query}
                        
#                         Follow {sql_dialect}'s syntax rules and functions."""
#                         query = APPCFG.langchain_llm.invoke(conversion_prompt).content
#                         query = query.replace("```sql", "").replace("```", "").strip()
                    
#                     # Execute query (SQLite doesn't support Trino/Spark directly)
#                     result = str(QuerySQLDataBaseTool(db=db).run(query))
#                     clean_result = ChatBot._clean_sql_result(result)
                    
#                     explanation_prompt = f"""Explain this {sql_dialect} SQL query in simple terms:
#                     {query}
                    
#                     Results: {clean_result}
                    
#                     Consider this conversation context:
#                     {chat_history}"""
#                     explanation = APPCFG.langchain_llm.invoke(explanation_prompt).content
                    
#                     response = f"""SQL Query ({sql_dialect}):
# {query}

# Results: {clean_result}
# Explanation: {explanation}"""
#                     chatbot.append((message, response))
#                     return "", chatbot
            
#                 except Exception as e:
#                     error_msg = f"Error executing {sql_dialect} query: {str(e)}"
#                     error_explanation = APPCFG.langchain_llm.invoke(
#                         f"Explain this SQL error in simple terms: {str(e)}"
#                     ).content
                
#                     chatbot.append((message, f"{error_msg}\n\nError Explanation: {error_explanation}"))
#                     return "", chatbot
#             else:
#                 chatbot.append((message, "Please upload a CSV/XLSX file first"))
#                 return "", chatbot


import os
import re
from typing import List, Tuple
from utils.load_config import LoadConfig
from langchain_community.utilities import SQLDatabase
from langchain.chains import create_sql_query_chain
from langchain_community.tools.sql_database.tool import QuerySQLDataBaseTool
from sqlalchemy import create_engine

APPCFG = LoadConfig()

class ChatBot:
    @staticmethod
    def _format_sql_response(response: str) -> str:
        """Format SQL response to clean up output"""
        response = response.replace("```sql", "").replace("```", "").strip()
        
        if "SQL Query:" in response and "Explanation:" in response:
            parts = response.split("SQL Query:", 1)[1].split("Explanation:", 1)
            query = parts[0].strip()
            explanation = parts[1].strip()
            return f"SQL Query:\n{query}\n\nExplanation:\n{explanation}"
        return response

    @staticmethod
    def _clean_sql_result(result: str) -> str:
        """Clean up SQL result to display just the number"""
        match = re.search(r'\((\d+)\)', result)
        return match.group(1) if match else result

    @staticmethod
    def respond(chatbot: List, message: str, app_functionality: str, sql_dialect: str = "Standard", feedback: str = None) -> Tuple[str, List]:
        # Basic greetings handling
        lower_msg = message.lower().strip()
        greetings = {
            'hello': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
            'hi': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
            'hey': "**AskQL** here! Your intelligent SQL assistant. How can I help you with your database queries today?",
            'thanks': "You're welcome! **AskQL** is always happy to assist with your data needs. Let me know if you have more questions!",
            'thank you': "You're welcome! **AskQL** is always happy to assist with your data needs. Let me know if you have more questions!",
            'bye': "Goodbye from **AskQL**! Remember - when you need SQL help, just ask QL!",
            'what is askql': "I'm **AskQL** - your smart SQL assistant!\nFeatures:\n- Generate optimized SQL queries\n- Explain queries in simple terms\n- Support multiple SQL dialects\n- Analyze your data files\n\nTry asking me anything about SQL!",
            'who are you': "I'm **AskQL** - your smart SQL assistant!\nFeatures:\n- Generate optimized SQL queries\n- Explain queries in simple terms\n- Support multiple SQL dialects\n- Analyze your data files\n\nTry asking me anything about SQL!"
        }
        
        if lower_msg in greetings:
            chatbot.append((message, greetings[lower_msg]))
            return "", chatbot

        # Add context from previous messages
        chat_history = "\nPrevious conversation:\n"
        for user_msg, bot_resp in chatbot[-5:]:  # Only keep last 5 exchanges for context
            chat_history += f"User: {user_msg}\nAssistant: {bot_resp}\n"

        # Check for negative feedback in the message
        is_negative_feedback = feedback == "no" or "no" in lower_msg

        # SQL Generation
        if app_functionality == "SQL Chat":
            try:
                dialect_prompt = {
                    "Trino": "Generate SQL in Trino dialect. Follow these best practices: "
                             "Use double quotes for identifiers, Prefer array_agg() over GROUP_CONCAT(), "
                             "approx_distinct() instead of COUNT(DISTINCT) when working with large datasets,"
                             "Prefer FILTER(WHERE condition) over CASE WHEN inside aggregation functions for better readability,"
                             "When using LIMIT, consider ordering the results explicitly to avoid non-deterministic behavior,"
                             "Use CAST() instead of :: for type conversions,"
                             "Prefer ANSI JOIN syntax (INNER JOIN, LEFT JOIN, etc.) instead of implicit joins,"
                             "Always qualify column names when joining multiple tables to prevent ambiguity,"
                             "For window functions, explicitly define the partition and order clauses (e.g., PARTITION BY column ORDER BY column),"
                             "Avoid using SELECT * in production queries; explicitly specify required columns for efficiency,"
                             "Use UNNEST(array_column) instead of EXPLODE() to flatten arrays,"
                             "Combine CROSS JOIN UNNEST(array_column) when dealing with multiple arrays,"
                             "Prefer array_join() for converting arrays to delimited strings.",
                             
                    "Spark": "Generate SQL in Spark SQL dialect. Follow these best practices: " 
                             "Use backticks (`) for identifiers instead of double quotes," 
                             "Prefer collect_list() over GROUP_CONCAT()," 
                             "Use approx_count_distinct() instead of COUNT(DISTINCT) for performance optimization on large datasets,"  
                             "When filtering NULL values, use IS NOT NULL instead of <> NULL," 
                             "Always specify the column alias explicitly when using aggregate functions,"  
                             "Use IF() or CASE WHEN instead of Trino's FILTER(WHERE condition),"  
                             "Spark supports Common Table Expressions (CTEs) (WITH clause), so use them for readability in complex queries," 
                             "Use sort_array() when sorting arrays instead of manually ordering elements in collect_list(),"  
                             "Always use DISTRIBUTE BY or SORT BY for performance tuning in large-scale aggregations,"  
                             "When dealing with JSON data, use get_json_object() or json_tuple() instead of ->>,"  
                             "Use EXPLODE(array_column) instead of UNNEST() to flatten arrays,"  
                             "Prefer posexplode() when the index position of elements is needed,"  
                             "Use concat_ws() for converting arrays into comma-separated strings."  
                }.get(sql_dialect, "")
                
                # Different prompt for negative feedback
                if is_negative_feedback:
                            prompt = f"""The user was not satisfied with the previous SQL query. Please generate a completely different but correct implementation that:

                        1. **Must Differ Structurally** from:
                        `SELECT COUNT(DISTINCT employee_id) AS UniqueEmployeeCount FROM employees;`

                        2. **Alternative Approaches** (choose at least 2):
                        - Use a subquery with GROUP BY instead of COUNT(DISTINCT)
                        - Implement a window function approach
                        - Use a CTE (WITH clause) for better readability
                        - Add filtering conditions if appropriate
                        - Change the aggregation method

                        3. **For {sql_dialect} Dialect**:
                        {dialect_prompt}

                        4. **Required Output Format**:
                        SQL Query: [new query here]
                        Explanation: 
                        - Clearly state how this differs from the previous version
                        - Explain why this approach might be better
                        - Note any trade-offs or considerations

                        Example of good differentiation:
                        "Instead of using COUNT(DISTINCT), this version uses a subquery with GROUP BY which can be more efficient on large datasets in {sql_dialect}. We've also added a department filter to match the user's implied needs."

                        **Important**: The new query must:
                        - Produce identical correct results
                        - Have visibly different SQL structure
                        - Maintain or improve performance"""
                else:
                    prompt = f"""You are a SQL expert assistant. For this request:
                    {chat_history}
                    Current request: {message}

                    {dialect_prompt}
                    1. Generate the appropriate SQL query
                    2. Explain what the query does
                    3. Consider the previous conversation context when appropriate

                    Format your response as:
                    SQL Query: [query here]
                    Explanation: [explanation here]
                    """
                
                response = APPCFG.langchain_llm.invoke(prompt).content
                formatted_response = ChatBot._format_sql_response(response)
                chatbot.append((message, formatted_response))
                return "", chatbot
            
            except Exception as e:
                chatbot.append((message, f"Error: {str(e)}"))
                return "", chatbot
        
        # File Analysis (unchanged)
        elif app_functionality == "File Analysis":
            if os.path.exists(APPCFG.uploaded_files_sqldb_directory):
                try:
                    engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
                    db = SQLDatabase(engine)
                    
                    # Generate SQL query with dialect consideration and chat history
                    question_with_history = f"{chat_history}\nCurrent question: {message}"
                    base_query = create_sql_query_chain(APPCFG.langchain_llm, db).invoke({"question": question_with_history})
                    query = base_query.replace("SQLQuery:", "").strip()
                    
                    # Convert to selected dialect if needed
                    if sql_dialect in ["Trino", "Spark"]:
                        conversion_prompt = f"""Convert this SQL to {sql_dialect} dialect:
                        {query}
                        
                        Follow {sql_dialect}'s syntax rules and functions."""
                        query = APPCFG.langchain_llm.invoke(conversion_prompt).content
                        query = query.replace("```sql", "").replace("```", "").strip()
                    
                    # Execute query (SQLite doesn't support Trino/Spark directly)
                    result = str(QuerySQLDataBaseTool(db=db).run(query))
                    clean_result = ChatBot._clean_sql_result(result)
                    
                    explanation_prompt = f"""Explain this {sql_dialect} SQL query in simple terms:
                    {query}
                    
                    Results: {clean_result}
                    
                    Consider this conversation context:
                    {chat_history}"""
                    explanation = APPCFG.langchain_llm.invoke(explanation_prompt).content
                    
                    response = f"""SQL Query ({sql_dialect}):
{query}

Results: {clean_result}
Explanation: {explanation}"""
                    chatbot.append((message, response))
                    return "", chatbot
            
                except Exception as e:
                    error_msg = f"Error executing {sql_dialect} query: {str(e)}"
                    error_explanation = APPCFG.langchain_llm.invoke(
                        f"Explain this SQL error in simple terms: {str(e)}"
                    ).content
                
                    chatbot.append((message, f"{error_msg}\n\nError Explanation: {error_explanation}"))
                    return "", chatbot
            else:
                chatbot.append((message, "Please upload a CSV/XLSX file first"))
                return "", chatbot