import os
import sys
import tempfile
sys.path.append(os.path.abspath(os.path.dirname(__file__)))
from typing import List
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from fastapi import UploadFile as FastAPIUploadFile



# Initialize app
app = FastAPI()

# CORS setup
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Response models
class UploadResponse(BaseModel):
    status: str
    message: str
    data: list

class ChatResponse(BaseModel):
    status: str
    response: str

# Import your existing modules
try:
    from utils.upload_file import UploadFile
    from utils.chatbot import ChatBot
except ImportError:
    # Fallback for direct module running
    from .utils.upload_file import UploadFile
    from .utils.chatbot import ChatBot

@app.post("/upload", response_model=UploadResponse)
async def upload_files(files: List[FastAPIUploadFile] = File(...)):
    try:
        file_paths = []
        for file in files:
            # Create temp file
            temp_dir = tempfile.mkdtemp()
            file_path = os.path.join(temp_dir, file.filename)
            with open(file_path, "wb") as buffer:
                buffer.write(await file.read())
            file_paths.append(file_path)
        
        # Process using your existing code
        chatbot = []
        _, updated_chatbot = UploadFile.run_pipeline(file_paths, chatbot, "File Analysis")
        
        # Cleanup
        for path in file_paths:
            os.unlink(path)
            os.rmdir(os.path.dirname(path))
            
        return {
            "status": "success",
            "message": "Files processed successfully",
            "data": updated_chatbot
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"File processing error: {str(e)}"
        )

@app.post("/chat", response_model=ChatResponse)
async def handle_chat(message: str, mode: str = "SQL Chat", dialect: str = "Standard"):
    try:
        chatbot = []
        _, updated_chatbot = ChatBot.respond(chatbot, message, mode, dialect)
        return {
            "status": "success",
            "response": updated_chatbot[-1][1] if updated_chatbot else "No response"
        }
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Chat error: {str(e)}"
        )

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)