from flask import Flask, request, jsonify, send_from_directory
from flask_cors import CORS
import sqlite3
from utils.chatbot import ChatBot
from utils.load_config import LoadConfig
from sqlalchemy import create_engine, text
import os
from datetime import datetime
import json
from werkzeug.utils import secure_filename
from sklearn.metrics.pairwise import cosine_similarity
from sentence_transformers import SentenceTransformer
import numpy as np

app = Flask(__name__)
CORS(app, resources={
    r"/api/*": {
        "origins": ["http://localhost:3000"],
        "methods": ["GET", "POST", "OPTIONS"],
        "allow_headers": ["Content-Type"]
    }
})

# Initialize config
APPCFG = LoadConfig()
feedback_model = SentenceTransformer('all-MiniLM-L6-v2')


# Configure upload folder
UPLOAD_FOLDER = 'uploads'
os.makedirs(UPLOAD_FOLDER, exist_ok=True)
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit

# Allowed file extensions
ALLOWED_EXTENSIONS = {'csv', 'xlsx'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def get_embedding(text):
    """Helper function to generate text embeddings"""
    return feedback_model.encode(text).tobytes()

@app.route('/api/execute-sql', methods=['POST'])
def execute_sql():
    try:
        data = request.get_json()
        query = data['query']
        
        if not os.path.exists(APPCFG.uploaded_files_sqldb_directory):
            return jsonify({
                "status": "error",
                "message": "No database available. Please upload files first.",
                "results": []
            }), 400
            
        engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
        
        with engine.connect() as conn:
            if query.strip().upper().startswith('SELECT'):
                result = conn.execute(text(query))
                columns = result.keys()
                rows = result.fetchall()
                results = [dict(zip(columns, row)) for row in rows]
                return jsonify({
                    "status": "success",
                    "results": results
                })
            else:
                conn.execute(text(query))
                conn.commit()
                return jsonify({
                    "status": "success",
                    "message": "Query executed successfully",
                    "results": []
                })
                
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e),
            "results": []
        }), 400

@app.route('/api/upload', methods=['POST'])
def upload_file():
    try:
        if 'files' not in request.files:
            return jsonify({
                "status": "error",
                "message": "No file part"
            }), 400
        
        files = request.files.getlist('files')
        uploaded_files = []
        
        for file in files:
            if file.filename == '':
                continue
            
            if file and allowed_file(file.filename):
                filename = secure_filename(file.filename)
                filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
                file.save(filepath)
                uploaded_files.append(filepath)
        
        if not uploaded_files:
            return jsonify({
                "status": "error",
                "message": "No valid files uploaded"
            }), 400
        
        from utils.upload_file import ProcessFiles
        chatbot = []
        ProcessFiles(uploaded_files, chatbot).run()
        
        return jsonify({
            "status": "success",
            "files": [os.path.basename(f) for f in uploaded_files],
            "messages": [msg[1] for msg in chatbot if msg[1]]
        })
    
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
        
@app.route('/api/get-schema', methods=['GET'])
def get_schema():
    try:
        if not os.path.exists(APPCFG.uploaded_files_sqldb_directory):
            return jsonify({
                "status": "error",
                "message": "No database available"
            }), 400
            
        engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
        
        with engine.connect() as conn:
            # Get all tables
            tables = conn.execute(text("""
                SELECT name FROM sqlite_master 
                WHERE type='table' 
                AND name NOT LIKE 'sqlite_%'
            """)).fetchall()
            
            schema = []
            for table in tables:
                table_name = table[0]
                # Get columns for each table
                columns = conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()
                schema.append({
                    "name": table_name,
                    "columns": [
                        {"name": col[1], "type": col[2]} 
                        for col in columns
                    ]
                })
            
            return jsonify({
                "status": "success",
                "schema": schema
            })
            
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 400

@app.route('/api/chat', methods=['POST'])
def chat_endpoint():
    try:
        data = request.get_json()
        
        _, chat_response = ChatBot.respond(
            [],
            data['message'],
            data.get('app_functionality', 'SQL Chat'),
            data.get('sql_dialect', 'Standard')
        )
        
        bot_response = chat_response[-1][1] if chat_response else "No response generated"
        
        return jsonify({
            "status": "success",
            "response": bot_response
        })
    
    except KeyError as e:
        return jsonify({
            "status": "error",
            "message": f"Missing required field: {str(e)}"
        }), 400
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": "Internal server error"
        }), 500

@app.route('/api/feedback', methods=['POST'])
def handle_feedback():
    try:
        feedback = request.get_json()
        
        # Store feedback in database (SQLite example)
        conn = sqlite3.connect('feedback.db')
        cursor = conn.cursor()
        
        # Create table if not exists
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS feedback (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                query TEXT,
                response TEXT,
                is_correct INTEGER,
                timestamp TEXT
            )
        ''')
        
        cursor.execute('''
            INSERT INTO feedback (query, response, is_correct, timestamp)
            VALUES (?, ?, ?, ?)
        ''', (
            feedback['query'],
            feedback['response'],
            1 if feedback['isCorrect'] else 0,
            feedback['timestamp']
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({"status": "success"})
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
@app.route('/api/store-approved-query', methods=['POST'])
def store_approved_query():
    """Store validated queries for future reuse"""
    try:
        data = request.get_json()
        prompt = data['prompt']
        sql_query = data['sql_query']
        
        conn = sqlite3.connect('feedback.db')
        cursor = conn.cursor()
        
        # Create approved_queries table if not exists
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS approved_queries (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                prompt TEXT NOT NULL UNIQUE,
                sql_query TEXT NOT NULL,
                prompt_embedding BLOB NOT NULL,
                usage_count INTEGER DEFAULT 1,
                last_used DATETIME DEFAULT CURRENT_TIMESTAMP
            )
        ''')
        
        # Generate embedding for the prompt
        embedding = feedback_model.encode(prompt)
        embedding_blob = embedding.tobytes()
        
        try:
            cursor.execute('''
                INSERT INTO approved_queries (prompt, sql_query, prompt_embedding)
                VALUES (?, ?, ?)
            ''', (prompt, sql_query, embedding_blob))
        except sqlite3.IntegrityError:
            # If prompt exists, update usage count
            cursor.execute('''
                UPDATE approved_queries 
                SET usage_count = usage_count + 1,
                    last_used = CURRENT_TIMESTAMP
                WHERE prompt = ?
            ''', (prompt,))
        
        conn.commit()
        conn.close()
        
        return jsonify({"status": "success"})
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/find-similar-query', methods=['POST'])
def find_similar_query():
    """Find similar approved queries using semantic search"""
    try:
        data = request.get_json()
        prompt = data['prompt']
        threshold = data.get('threshold', 0.85)  # Default similarity threshold
        
        conn = sqlite3.connect('feedback.db')
        cursor = conn.cursor()
        
        # Get all approved queries
        cursor.execute('SELECT prompt, sql_query, prompt_embedding FROM approved_queries')
        approved_queries = cursor.fetchall()
        
        if not approved_queries:
            return jsonify({"status": "success", "found": False})
        
        # Compare with current prompt
        current_embedding = feedback_model.encode(prompt)
        best_match = None
        max_similarity = 0
        
        for query in approved_queries:
            stored_embedding = np.frombuffer(query[2], dtype=np.float32)
            similarity = cosine_similarity(
                current_embedding.reshape(1, -1),
                stored_embedding.reshape(1, -1)
            )[0][0]
            
            if similarity > max_similarity:
                max_similarity = similarity
                best_match = query
        
        if max_similarity >= threshold:
            return jsonify({
                "status": "success",
                "found": True,
                "prompt": best_match[0],
                "sql_query": best_match[1],
                "similarity": float(max_similarity)
            })
        
        return jsonify({"status": "success", "found": False})
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

@app.route('/api/feedback-stats', methods=['GET'])
def get_feedback_stats():
    """Get feedback statistics for analytics"""
    try:
        conn = sqlite3.connect('feedback.db')
        cursor = conn.cursor()
        
        # Get total feedback count
        cursor.execute('SELECT COUNT(*) FROM feedback')
        total_feedback = cursor.fetchone()[0]
        
        # Get positive/negative ratio
        cursor.execute('SELECT is_correct, COUNT(*) FROM feedback GROUP BY is_correct')
        feedback_counts = {row[0]: row[1] for row in cursor.fetchall()}
        
        # Get most common queries
        cursor.execute('''
            SELECT query, COUNT(*) as count 
            FROM feedback 
            GROUP BY query 
            ORDER BY count DESC 
            LIMIT 5
        ''')
        top_queries = [{"query": row[0], "count": row[1]} for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            "status": "success",
            "total_feedback": total_feedback,
            "positive_feedback": feedback_counts.get(1, 0),
            "negative_feedback": feedback_counts.get(0, 0),
            "top_queries": top_queries
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500
@app.route('/api/regenerate-query', methods=['POST'])
def regenerate_query():
    try:
        data = request.get_json()
        prompt = data['prompt']
        previous_query = data.get('previous_query', '')
        
        # Get similar queries to avoid repeating mistakes
        similar_queries = []
        conn = sqlite3.connect('feedback.db')
        cursor = conn.cursor()
        cursor.execute('SELECT sql_query FROM feedback WHERE query = ? AND is_correct = 0', (prompt,))
        similar_queries = [row[0] for row in cursor.fetchall()]
        conn.close()
        
        # Regenerate query using your existing chatbot
        # (This uses your existing ChatBot.respond() functionality)
        _, chat_response = ChatBot.respond(
            [],
            prompt,
            'SQL Chat',  # Default mode
            'Standard'   # Default dialect
        )
        
        new_query = chat_response[-1][1] if chat_response else "No response generated"
        
        # Avoid returning the same query
        if new_query.strip() == previous_query.strip():
            new_query = "SELECT * FROM " + prompt.split()[0].lower() + " LIMIT 10;"
        
        return jsonify({
            "status": "success",
            "new_query": new_query
        })
        
    except Exception as e:
        return jsonify({
            "status": "error",
            "message": str(e)
        }), 500

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)

# from flask import Flask, request, jsonify, send_from_directory
# from flask_cors import CORS
# import sqlite3
# from utils.chatbot import ChatBot
# from utils.load_config import LoadConfig
# from sqlalchemy import create_engine, text
# import os
# from datetime import datetime
# import json
# from werkzeug.utils import secure_filename
# from sklearn.metrics.pairwise import cosine_similarity
# from sentence_transformers import SentenceTransformer
# import numpy as np
# import faiss

# app = Flask(__name__)
# CORS(app, resources={
#     r"/api/*": {
#         "origins": ["http://localhost:3000"],
#         "methods": ["GET", "POST", "OPTIONS"],
#         "allow_headers": ["Content-Type"]
#     }
# })

# # Initialize config
# APPCFG = LoadConfig()
# feedback_model = SentenceTransformer('all-MiniLM-L6-v2')

# class VectorDB:
#     def __init__(self):
#         self.index = faiss.IndexFlatL2(384)  # 384 dimensions
#         self.mapping = {}
        
#     def add_vector(self, id, embedding):
#         self.index.add(np.array([embedding]))
#         self.mapping[id] = len(self.mapping)
        
#     def search(self, embedding, k=5):
#         D, I = self.index.search(np.array([embedding]), k)
#         return [(i, 1 - d) for i, d in zip(I[0], D[0])]  # Convert to similarity

# vector_db = VectorDB()

# # Configure upload folder
# UPLOAD_FOLDER = 'uploads'
# os.makedirs(UPLOAD_FOLDER, exist_ok=True)
# app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
# app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB limit

# # Allowed file extensions
# ALLOWED_EXTENSIONS = {'csv', 'xlsx'}

# def allowed_file(filename):
#     return '.' in filename and \
#            filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# def get_embedding(text):
#     """Helper function to generate text embeddings"""
#     return feedback_model.encode(text).tobytes()

# @app.route('/api/execute-sql', methods=['POST'])
# def execute_sql():
#     try:
#         data = request.get_json()
#         query = data['query']
        
#         if not os.path.exists(APPCFG.uploaded_files_sqldb_directory):
#             return jsonify({
#                 "status": "error",
#                 "message": "No database available. Please upload files first.",
#                 "results": []
#             }), 400
            
#         engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
        
#         with engine.connect() as conn:
#             if query.strip().upper().startswith('SELECT'):
#                 result = conn.execute(text(query))
#                 columns = result.keys()
#                 rows = result.fetchall()
#                 results = [dict(zip(columns, row)) for row in rows]
#                 return jsonify({
#                     "status": "success",
#                     "results": results
#                 })
#             else:
#                 conn.execute(text(query))
#                 conn.commit()
#                 return jsonify({
#                     "status": "success",
#                     "message": "Query executed successfully",
#                     "results": []
#                 })
                
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e),
#             "results": []
#         }), 400

# @app.route('/api/upload', methods=['POST'])
# def upload_file():
#     try:
#         if 'files' not in request.files:
#             return jsonify({
#                 "status": "error",
#                 "message": "No file part"
#             }), 400
        
#         files = request.files.getlist('files')
#         uploaded_files = []
        
#         for file in files:
#             if file.filename == '':
#                 continue
            
#             if file and allowed_file(file.filename):
#                 filename = secure_filename(file.filename)
#                 filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
#                 file.save(filepath)
#                 uploaded_files.append(filepath)
        
#         if not uploaded_files:
#             return jsonify({
#                 "status": "error",
#                 "message": "No valid files uploaded"
#             }), 400
        
#         from utils.upload_file import ProcessFiles
#         chatbot = []
#         ProcessFiles(uploaded_files, chatbot).run()
        
#         return jsonify({
#             "status": "success",
#             "files": [os.path.basename(f) for f in uploaded_files],
#             "messages": [msg[1] for msg in chatbot if msg[1]]
#         })
    
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500
        
# @app.route('/api/get-schema', methods=['GET'])
# def get_schema():
#     try:
#         if not os.path.exists(APPCFG.uploaded_files_sqldb_directory):
#             return jsonify({
#                 "status": "error",
#                 "message": "No database available"
#             }), 400
            
#         engine = create_engine(f"sqlite:///{APPCFG.uploaded_files_sqldb_directory}")
        
#         with engine.connect() as conn:
#             # Get all tables
#             tables = conn.execute(text("""
#                 SELECT name FROM sqlite_master 
#                 WHERE type='table' 
#                 AND name NOT LIKE 'sqlite_%'
#             """)).fetchall()
            
#             schema = []
#             for table in tables:
#                 table_name = table[0]
#                 # Get columns for each table
#                 columns = conn.execute(text(f"PRAGMA table_info({table_name})")).fetchall()
#                 schema.append({
#                     "name": table_name,
#                     "columns": [
#                         {"name": col[1], "type": col[2]} 
#                         for col in columns
#                     ]
#                 })
            
#             return jsonify({
#                 "status": "success",
#                 "schema": schema
#             })
            
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 400

# @app.route('/api/chat', methods=['POST'])
# def chat_endpoint():
#     try:
#         data = request.get_json()
        
#         _, chat_response = ChatBot.respond(
#             [],
#             data['message'],
#             data.get('app_functionality', 'SQL Chat'),
#             data.get('sql_dialect', 'Standard')
#         )
        
#         bot_response = chat_response[-1][1] if chat_response else "No response generated"
        
#         return jsonify({
#             "status": "success",
#             "response": bot_response
#         })
    
#     except KeyError as e:
#         return jsonify({
#             "status": "error",
#             "message": f"Missing required field: {str(e)}"
#         }), 400
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": "Internal server error"
#         }), 500

# @app.route('/api/feedback', methods=['POST'])
# def handle_feedback():
#     try:
#         feedback = request.get_json()
#         embedding = feedback_model.encode(feedback['query'])
        
#         # Connect to SQLite (original database)
#         conn = sqlite3.connect('feedback.db')
#         cursor = conn.cursor()
        
#         # Create table if not exists (original schema)
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS feedback (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 query TEXT,
#                 response TEXT,
#                 is_correct INTEGER,
#                 timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
#             )
#         ''')
        
#         # Insert into SQLite (original format)
#         cursor.execute('''
#             INSERT INTO feedback (query, response, is_correct)
#             VALUES (?, ?, ?)
#         ''', (
#             feedback['query'],
#             feedback['response'],
#             1 if feedback['isCorrect'] else 0
#         ))
        
#         feedback_id = cursor.lastrowid
#         conn.commit()
        
#         # Store in vector DB
#         vector_db.add_vector(
#             feedback_id=feedback_id,
#             embedding=embedding,
#             query=feedback['query'],
#             response=feedback['response'],
#             is_correct=1 if feedback['isCorrect'] else 0
#         )
        
#         conn.close()
#         return jsonify({"status": "success"})
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500
# @app.route('/api/store-approved-query', methods=['POST'])
# def store_approved_query():
#     """Store validated queries for future reuse"""
#     try:
#         data = request.get_json()
#         prompt = data['prompt']
#         sql_query = data['sql_query']
        
#         conn = sqlite3.connect('feedback.db')
#         cursor = conn.cursor()
        
#         # Create approved_queries table if not exists
#         cursor.execute('''
#             CREATE TABLE IF NOT EXISTS approved_queries (
#                 id INTEGER PRIMARY KEY AUTOINCREMENT,
#                 prompt TEXT NOT NULL UNIQUE,
#                 sql_query TEXT NOT NULL,
#                 prompt_embedding BLOB NOT NULL,
#                 usage_count INTEGER DEFAULT 1,
#                 last_used DATETIME DEFAULT CURRENT_TIMESTAMP
#             )
#         ''')
        
#         # Generate embedding for the prompt
#         embedding = feedback_model.encode(prompt)
#         embedding_blob = embedding.tobytes()
        
#         try:
#             cursor.execute('''
#                 INSERT INTO approved_queries (prompt, sql_query, prompt_embedding)
#                 VALUES (?, ?, ?)
#             ''', (prompt, sql_query, embedding_blob))
#         except sqlite3.IntegrityError:
#             # If prompt exists, update usage count
#             cursor.execute('''
#                 UPDATE approved_queries 
#                 SET usage_count = usage_count + 1,
#                     last_used = CURRENT_TIMESTAMP
#                 WHERE prompt = ?
#             ''', (prompt,))
        
#         conn.commit()
#         conn.close()
        
#         return jsonify({"status": "success"})
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500
# @app.route('/api/find-similar-feedback', methods=['POST'])
# def find_similar_feedback():
#     try:
#         data = request.get_json()
#         prompt = data['prompt']
#         threshold = data.get('threshold', 0.85)
        
#         embedding = feedback_model.encode(prompt)
#         results = vector_db.search(embedding, threshold)
        
#         if results:
#             best_match = max(results, key=lambda x: x['similarity'])
#             return jsonify({
#                 "status": "success",
#                 "found": True,
#                 "query": best_match['query'],
#                 "response": best_match['response'],
#                 "similarity": best_match['similarity']
#             })
        
#         return jsonify({"status": "success", "found": False})
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500
        
# @app.route('/api/find-similar-query', methods=['POST'])
# def find_similar_query():
#     """Find similar approved queries using semantic search"""
#     try:
#         data = request.get_json()
#         prompt = data['prompt']
#         threshold = data.get('threshold', 0.85)  # Default similarity threshold
        
#         conn = sqlite3.connect('feedback.db')
#         cursor = conn.cursor()
        
#         # Get all approved queries
#         cursor.execute('SELECT prompt, sql_query, prompt_embedding FROM approved_queries')
#         approved_queries = cursor.fetchall()
        
#         if not approved_queries:
#             return jsonify({"status": "success", "found": False})
        
#         # Compare with current prompt
#         current_embedding = feedback_model.encode(prompt)
#         best_match = None
#         max_similarity = 0
        
#         for query in approved_queries:
#             stored_embedding = np.frombuffer(query[2], dtype=np.float32)
#             similarity = cosine_similarity(
#                 current_embedding.reshape(1, -1),
#                 stored_embedding.reshape(1, -1)
#             )[0][0]
            
#             if similarity > max_similarity:
#                 max_similarity = similarity
#                 best_match = query
        
#         if max_similarity >= threshold:
#             return jsonify({
#                 "status": "success",
#                 "found": True,
#                 "prompt": best_match[0],
#                 "sql_query": best_match[1],
#                 "similarity": float(max_similarity)
#             })
        
#         return jsonify({"status": "success", "found": False})
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500

# @app.route('/api/feedback-stats', methods=['GET'])
# def get_feedback_stats():
#     """Get feedback statistics for analytics"""
#     try:
#         conn = sqlite3.connect('feedback.db')
#         cursor = conn.cursor()
        
#         # Get total feedback count
#         cursor.execute('SELECT COUNT(*) FROM feedback')
#         total_feedback = cursor.fetchone()[0]
        
#         # Get positive/negative ratio
#         cursor.execute('SELECT is_correct, COUNT(*) FROM feedback GROUP BY is_correct')
#         feedback_counts = {row[0]: row[1] for row in cursor.fetchall()}
        
#         # Get most common queries
#         cursor.execute('''
#             SELECT query, COUNT(*) as count 
#             FROM feedback 
#             GROUP BY query 
#             ORDER BY count DESC 
#             LIMIT 5
#         ''')
#         top_queries = [{"query": row[0], "count": row[1]} for row in cursor.fetchall()]
        
#         conn.close()
        
#         return jsonify({
#             "status": "success",
#             "total_feedback": total_feedback,
#             "positive_feedback": feedback_counts.get(1, 0),
#             "negative_feedback": feedback_counts.get(0, 0),
#             "top_queries": top_queries
#         })
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500
# @app.route('/api/regenerate-query', methods=['POST'])
# def regenerate_query():
#     try:
#         data = request.get_json()
#         prompt = data['prompt']
#         previous_query = data.get('previous_query', '')
        
#         # Get similar queries to avoid repeating mistakes
#         similar_queries = []
#         conn = sqlite3.connect('feedback.db')
#         cursor = conn.cursor()
#         cursor.execute('SELECT sql_query FROM feedback WHERE query = ? AND is_correct = 0', (prompt,))
#         similar_queries = [row[0] for row in cursor.fetchall()]
#         conn.close()
        
#         # Regenerate query using your existing chatbot
#         # (This uses your existing ChatBot.respond() functionality)
#         _, chat_response = ChatBot.respond(
#             [],
#             prompt,
#             'SQL Chat',  # Default mode
#             'Standard'   # Default dialect
#         )
        
#         new_query = chat_response[-1][1] if chat_response else "No response generated"
        
#         # Avoid returning the same query
#         if new_query.strip() == previous_query.strip():
#             new_query = "SELECT * FROM " + prompt.split()[0].lower() + " LIMIT 10;"
        
#         return jsonify({
#             "status": "success",
#             "new_query": new_query
#         })
        
#     except Exception as e:
#         return jsonify({
#             "status": "error",
#             "message": str(e)
#         }), 500

# if __name__ == '__main__':
#     app.run(host='0.0.0.0', port=5000, debug=True)