import sqlite3
from typing import Optional
from datetime import datetime
import hashlib

class FeedbackDB:
    def __init__(self, db_path: str = "feedback_store.db"):
        self.conn = sqlite3.connect(db_path)
        self._create_table()
        
    def _create_table(self):
        cursor = self.conn.cursor()
        cursor.execute("""
        CREATE TABLE IF NOT EXISTS feedback (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            prompt_hash TEXT NOT NULL,
            prompt_text TEXT NOT NULL,
            sql_query TEXT NOT NULL,
            is_correct INTEGER NOT NULL,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
            UNIQUE(prompt_hash, sql_query)
        )
        """)
        self.conn.commit()
    
    def _hash_prompt(self, prompt: str) -> str:
        return hashlib.md5(prompt.encode()).hexdigest()
    
    def store_feedback(self, prompt: str, sql_query: str, is_correct: bool):
        prompt_hash = self._hash_prompt(prompt)
        cursor = self.conn.cursor()
        cursor.execute("""
        INSERT OR REPLACE INTO feedback 
        (prompt_hash, prompt_text, sql_query, is_correct) 
        VALUES (?, ?, ?, ?)
        """, (prompt_hash, prompt, sql_query, int(is_correct)))
        self.conn.commit()
    
    def get_best_query(self, prompt: str) -> Optional[str]:
        prompt_hash = self._hash_prompt(prompt)
        cursor = self.conn.cursor()
        cursor.execute("""
        SELECT sql_query FROM feedback 
        WHERE prompt_hash = ? AND is_correct = 1
        ORDER BY timestamp DESC
        LIMIT 1
        """, (prompt_hash,))
        result = cursor.fetchone()
        return result[0] if result else None
    
    def close(self):
        self.conn.close()