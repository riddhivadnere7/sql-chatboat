# AskQL — Complete Project Guide (For Your Colleague)

> **What is this document?** This is the *only* document you will ever need to understand, run, modify, and debug the AskQL project. It is written for someone who has never seen this codebase before. Read it top to bottom.

---

## Table of Contents

1. [What is AskQL? (The Big Picture)](#1-what-is-askql-the-big-picture)
2. [Architecture Overview](#2-architecture-overview)
3. [Technology Stack Explained](#3-technology-stack-explained)
4. [Folder Structure — What Every File Does](#4-folder-structure--what-every-file-does)
5. [Backend Deep Dive](#5-backend-deep-dive)
6. [Frontend Deep Dive](#6-frontend-deep-dive)
7. [The Feedback System — The Core Innovation](#7-the-feedback-system--the-core-innovation)
8. [Data Flow — How a User Request Travels](#8-data-flow--how-a-user-request-travels)
9. [API Endpoints Reference](#9-api-endpoints-reference)
10. [How to Set Up and Run the Project](#10-how-to-set-up-and-run-the-project)
11. [Common Issues and Debugging](#11-common-issues-and-debugging)
12. [Key Concepts You Must Understand](#12-key-concepts-you-must-understand)

---

## 1. What is AskQL? (The Big Picture)

**AskQL** is an AI-powered chatbot web application that converts **natural language questions into SQL queries**. 

### In Simple Words:
Imagine a person who doesn't know SQL but has data in a CSV/Excel file. They can:
1. Upload their file to AskQL
2. Type a question like *"How many customers purchased last month?"*
3. AskQL uses **Google Gemini AI** to generate the correct SQL query
4. The app can even **execute** that SQL query on their uploaded data and show results
5. The user gives **feedback** (👍 or 👎) on whether the AI generated the right query
6. The system **learns** from feedback — next time someone asks a similar question, it reuses the approved query instead of generating a new one

### Why Does This Project Exist?
This project demonstrates a **feedback loop** for AI-generated SQL. The key research question is: *Can we improve the accuracy of AI-generated SQL by storing user feedback and reusing previously approved queries?*

### The Three Modes of Operation:

| Mode | What It Does | When To Use |
|------|-------------|-------------|
| **SQL Chat** | Takes a natural language question → generates SQL query + explanation | When you want SQL help but don't have data uploaded |
| **File Analysis** | Upload CSV/XLSX → converts to SQLite → ask questions about your data | When you have actual data to query |
| **SQL IDE** | Write and execute raw SQL against uploaded data | When you already know SQL and want to run it directly |

---

## 2. Architecture Overview

```mermaid
graph TB
    subgraph "Frontend (React - Port 3000)"
        A["Homepage.js<br/>Landing Page"] --> B["Home.js<br/>Main Chat Interface"]
        B --> C["SqlIde.js<br/>SQL Editor"]
        B --> D["Feedback.js<br/>👍👎 Buttons"]
        B --> E["File.Upload.js<br/>CSV/XLSX Upload"]
    end

    subgraph "Backend (Flask - Port 5000)"
        F["/api/chat"] --> G["ChatBot.respond()"]
        H["/api/upload"] --> I["ProcessFiles"]
        J["/api/execute-sql"] --> K["SQLAlchemy Engine"]
        L["/api/feedback"] --> M["feedback.db"]
        N["/api/store-approved-query"] --> M
        O["/api/find-similar-query"] --> M
        P["/api/get-schema"] --> K
    end

    subgraph "AI Layer"
        G --> Q["Google Gemini 1.5 Pro<br/>(via LangChain)"]
    end

    subgraph "Data Layer"
        M["feedback.db<br/>(Feedback + Approved Queries)"]
        R["uploaded_files_sqldb.db<br/>(User's uploaded data)"]
    end

    B -->|HTTP POST| F
    B -->|HTTP POST| H
    B -->|HTTP POST| J
    B -->|HTTP POST| L
    C -->|HTTP POST| J
    C -->|HTTP GET| P
```

### How Frontend and Backend Talk to Each Other:
- The **frontend** (React) runs on `http://localhost:3000`
- The **backend** (Flask) runs on `http://localhost:5000`
- They communicate via **REST API calls** (HTTP requests with JSON data)
- **CORS** (Cross-Origin Resource Sharing) is configured to allow the frontend to call the backend

> [!IMPORTANT]
> Both the frontend and backend must be running simultaneously for the app to work. They are separate processes.

---

## 3. Technology Stack Explained

### Backend Technologies

| Technology | What It Is | Why It's Used Here |
|-----------|-----------|-------------------|
| **Python** | Programming language | The entire backend is written in Python |
| **Flask** | A lightweight web framework | Creates the HTTP server that handles API requests |
| **flask-cors** | CORS handling library | Allows the React frontend (port 3000) to call the Flask backend (port 5000) |
| **SQLite** | A file-based SQL database | Stores feedback data (`feedback.db`) and user-uploaded data (`uploaded_files_sqldb.db`) |
| **SQLAlchemy** | SQL toolkit and ORM | Provides a clean Python interface to interact with SQLite databases |
| **LangChain** | AI application framework | Connects to Google Gemini, creates SQL generation chains, handles prompts |
| **Google Gemini 1.5 Pro** | Large Language Model (LLM) | The AI brain that converts natural language to SQL |
| **SentenceTransformer** | ML model for text embeddings | Converts text into numerical vectors for similarity search (`all-MiniLM-L6-v2`) |
| **scikit-learn** | Machine learning library | Provides `cosine_similarity` to compare how similar two prompts are |
| **pandas** | Data manipulation library | Reads CSV/XLSX files and converts them to SQL tables |
| **PyYAML** | YAML parser | Reads the configuration file (`app_config.yml`) |
| **python-dotenv** | Environment variable loader | Loads API keys from `.env` files |

### Frontend Technologies

| Technology | What It Is | Why It's Used Here |
|-----------|-----------|-------------------|
| **React 19** | JavaScript UI library | Builds the entire user interface |
| **react-router-dom** | Navigation library | Handles page routing (Homepage → Chat page) |
| **axios** | HTTP client | Makes API calls to the Flask backend |
| **framer-motion** | Animation library | Creates smooth animations on the landing page |
| **react-icons** | Icon library | Provides icons (👍, 📁, ▶️, etc.) |
| **@monaco-editor/react** | VS Code editor component | Powers the SQL IDE with syntax highlighting |
| **ag-grid-react** | Data grid component | (Available for data table display) |
| **react-toastify** | Notification library | Shows toast notifications for success/error messages |

---

## 4. Folder Structure — What Every File Does

Here is every file that matters, and what it does:

### Root Level

```
askql_project/
├── .env                          ← Root env file (OpenAI vars, currently empty)
├── .gitignore                    ← Git ignore rules
├── backend/                      ← Python Flask backend
├── frontend/                     ← React frontend
└── F/                            ← ⚠️ Static HTML prototype (NOT USED, ignore this)
```

### Backend Structure

```
backend/
├── .env                          ← ⭐ API keys & server config
├── requirements.txt              ← Python package dependencies
├── setup.py                      ← Package setup (pip install -e .)
├── __init__.py                   ← Makes 'backend' a Python package
├── feedback.db                   ← ⭐ SQLite DB storing all feedback data
├── configs/
│   └── app_config.yml            ← ⭐ Application configuration
├── data/
│   └── uploaded_files_sqldb.db   ← SQLite DB created from user uploads
├── uploads/                      ← Where uploaded CSV/XLSX files are saved
├── src/
│   ├── __init__.py               ← Makes 'src' a Python package
│   ├── app.py                    ← ⭐⭐⭐ MAIN BACKEND FILE (Flask server)
│   ├── fastapi_app.py            ← Alternative FastAPI server (not primary)
│   ├── knowledge.py              ← FeedbackDB class for hash-based lookup
│   ├── prepare_csv_xlsx_sqlitedb.py  ← Script to pre-convert CSV→SQLite
│   ├── prepare_csv_xlsx_vectordb.py  ← Script to pre-convert CSV→ChromaDB
│   └── utils/
│       ├── __init__.py
│       ├── chatbot.py            ← ⭐⭐⭐ Core AI logic (prompt → SQL)
│       ├── load_config.py        ← ⭐ Loads config + initializes Gemini
│       ├── prepare_sqlitedb_from_csv_xlsx.py  ← CSV→SQLite conversion class
│       ├── prepare_vectordb_from_csv_xlsx.py  ← CSV→ChromaDB conversion class
│       ├── ui_settings.py        ← Gradio UI settings (legacy, from old UI)
│       └── upload_file.py        ← ⭐ Processes uploaded files → SQLite
```

### Frontend Structure

```
frontend/
├── package.json                  ← ⭐ Node.js dependencies & scripts
├── package-lock.json             ← Locked dependency versions
├── public/                       ← Static HTML template
├── src/
│   ├── index.js                  ← ⭐ React entry point
│   ├── index.css                 ← Global CSS
│   ├── App.js                    ← ⭐ Root component (routing logic)
│   ├── assets/                   ← Images (logo, consultation image)
│   ├── styles/
│   │   └── App.css               ← Global app styles
│   ├── services/
│   │   └── api.js                ← ⭐ Axios API client
│   └── components/
│       ├── Navbar.js + .css      ← Top navigation bar
│       ├── Homepage.js + .css    ← Landing page with animations
│       ├── Home.js + .css        ← ⭐⭐⭐ MAIN CHAT INTERFACE
│       ├── SqlIde.js + .css      ← ⭐ SQL IDE with Monaco Editor
│       ├── Feedback.js + .css    ← ⭐ Thumbs up/down feedback buttons
│       ├── File.Upload.js        ← File upload component
│       ├── Header.js             ← Simple header (used in SQLAssistant)
│       ├── SQLAssistant.js       ← Standalone SQL generator (not primary)
│       └── test.js               ← Test placeholder (ignore)
```

> [!NOTE]
> Files marked with ⭐⭐⭐ are the most critical files. If you modify any file, it will most likely be one of these.

---

## 5. Backend Deep Dive

### 5.1 The Configuration System

**File:** [load_config.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/utils/load_config.py)

This is the first thing that runs when the backend starts. It does three things:

1. **Loads `.env` file** → Gets the `GOOGLE_API_KEY` for Gemini AI
2. **Reads `app_config.yml`** → Gets file paths, LLM settings, RAG config
3. **Initializes Google Gemini** → Creates the LangChain LLM object that will generate SQL

```python
# What the config object gives you:
APPCFG.uploaded_files_sqldb_directory  # Path to the SQLite DB for uploaded data
APPCFG.model_name                      # "gemini-1.5-pro"
APPCFG.temperature                     # 0.0 (deterministic output, no randomness)
APPCFG.langchain_llm                   # The actual Gemini model instance
```

> [!IMPORTANT]
> **Why is `temperature` set to 0.0?** Because for SQL generation, you want *consistent, deterministic* output. A temperature of 0 means the AI always picks the most likely token. If you set it to 1.0, the AI would generate different SQL each time for the same question.

**File:** [app_config.yml](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/configs/app_config.yml)

```yaml
directories:
  uploaded_files_sqldb_directory: data/uploaded_files_sqldb.db  # Where user data lives
  
llm_config:
  agent_llm_system_role: "Given the following user question..."  # System prompt for SQL
  temperature: 0.0  # No randomness

rag_config:
  collection_name: titanic_small  # ChromaDB collection name
  top_k: 1  # Number of results to retrieve
```

### 5.2 The Main Backend Server — `app.py`

**File:** [app.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/app.py)

This is the **heart of the backend**. It's a Flask web server that exposes 8 API endpoints. Let me explain each one:

#### Startup Code (Lines 1-44)

```python
app = Flask(__name__)
CORS(app, resources={r"/api/*": {"origins": ["http://localhost:3000"], ...}})
```

- Creates a Flask app
- Enables CORS so the React frontend can call it
- Loads the configuration (`APPCFG = LoadConfig()`)
- Loads the SentenceTransformer model for embedding prompts into vectors

> [!NOTE]
> **What is SentenceTransformer?** It's a machine learning model that converts text into a fixed-size numerical vector (array of 384 numbers). Two similar sentences will have similar vectors. This is how the app finds "similar" queries — by comparing their vectors using cosine similarity.

#### Key Functions in app.py:

| Endpoint | Method | What It Does |
|----------|--------|-------------|
| `/api/chat` | POST | Takes a user's natural language question, sends it to Gemini AI, returns the generated SQL |
| `/api/execute-sql` | POST | Takes a raw SQL query, executes it against the uploaded database, returns results |
| `/api/upload` | POST | Accepts CSV/XLSX files, converts them to SQLite tables |
| `/api/get-schema` | GET | Returns the schema (table names + column names/types) of the uploaded database |
| `/api/feedback` | POST | Stores user's 👍/👎 feedback on a response |
| `/api/store-approved-query` | POST | Stores a positively-rated query with its embedding for future reuse |
| `/api/find-similar-query` | POST | Searches for previously approved queries that are semantically similar |
| `/api/feedback-stats` | GET | Returns analytics: total feedback count, positive/negative ratio, top queries |
| `/api/regenerate-query` | POST | Regenerates a new SQL query when user says 👎 |

> [!WARNING]
> The bottom half of `app.py` (lines 432-914) is **entirely commented-out code**. It contains an older version of the same endpoints (including a FAISS-based vector DB approach that was abandoned). **Do not uncomment it** — it will cause duplicate route definitions and crash the server.

### 5.3 The ChatBot — The AI Brain

**File:** [chatbot.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/utils/chatbot.py)

This file contains the `ChatBot` class with the core logic. The top half (lines 1-165) is commented-out old code. The active code starts at **line 167**.

#### How `ChatBot.respond()` works:

```
User types: "Show me all employees earning more than 50000"
         ↓
Step 1: Check if it's a greeting ("hello", "hi", "bye")
         ↓ (not a greeting)
Step 2: Build chat history from last 5 messages (for context)
         ↓
Step 3: Check which mode we're in
         ↓
┌─────────────────────┬────────────────────────┐
│   "SQL Chat" Mode   │  "File Analysis" Mode  │
├─────────────────────┼────────────────────────┤
│ Build a prompt with │ Connect to uploaded DB  │
│ dialect-specific    │ Use LangChain's SQL     │
│ best practices      │ chain to auto-generate  │
│ Send to Gemini      │ and EXECUTE the query   │
│ Return SQL +        │ Return SQL + results +  │
│ explanation         │ explanation             │
└─────────────────────┴────────────────────────┘
```

#### SQL Dialect Support:

The chatbot supports three SQL dialects. This matters because different databases use different SQL syntax:

| Dialect | Best Practices Included |
|---------|------------------------|
| **Standard** | Generic SQL, no special rules |
| **Trino** | Double quotes for identifiers, `array_agg()`, `CAST()`, ANSI JOIN, `UNNEST()` |
| **Spark** | Backtick identifiers, `collect_list()`, `EXPLODE()`, CTEs, `concat_ws()` |

#### Negative Feedback Handling (Lines 258-288):

When a user clicks 👎, the `feedback` parameter is set to `"no"`. The chatbot then uses a **completely different prompt** that specifically asks Gemini to:
1. Generate a **structurally different** query
2. Use alternative approaches (subqueries, window functions, CTEs)
3. Explain how the new query differs from the old one

This is the **regeneration** mechanism. Without it, Gemini would just generate the same query again.

### 5.4 File Upload Processing

**File:** [upload_file.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/utils/upload_file.py)

When a user uploads a CSV or XLSX file:

```
User uploads "employees.csv"
         ↓
Step 1: Save file to backend/uploads/
         ↓
Step 2: Read with pandas (pd.read_csv or pd.read_excel)
         ↓
Step 3: Create SQLAlchemy engine pointing to data/uploaded_files_sqldb.db
         ↓
Step 4: df.to_sql("employees", engine) 
         ↓
Now "employees" is a SQL table you can query!
```

> [!TIP]
> The table name comes from the filename (without extension). So `employees.csv` becomes table `employees`, and `sales_2024.xlsx` becomes table `sales_2024`.

### 5.5 The Knowledge/FeedbackDB Module

**File:** [knowledge.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/knowledge.py)

This is a standalone module (not directly used by `app.py` at runtime, but available as a utility). It uses **MD5 hashing** to look up previously stored correct queries:

```
Prompt: "count all employees" → MD5 hash: "a1b2c3d4..."
                                         ↓
                               Look up in feedback table
                                         ↓
                               Return the stored SQL query
```

This is a **simpler** approach compared to the embedding-based similarity search in `app.py`. The hash approach only works for **exact** prompt matches, while the embedding approach works for **semantically similar** prompts.

### 5.6 The FastAPI Alternative

**File:** [fastapi_app.py](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/backend/src/fastapi_app.py)

This is an alternative server implementation using FastAPI instead of Flask. It runs on port 8000 and provides `/upload` and `/chat` endpoints. 

> [!NOTE]
> The frontend's `api.js` service file points to port 8000, but the `Home.js` component (the actual chat interface) calls port 5000. **The primary server is Flask on port 5000**. The FastAPI file exists as an experimental alternative.

---

## 6. Frontend Deep Dive

### 6.1 Application Entry Point

**File:** [index.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/index.js) → [App.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/App.js)

The app starts in `index.js`, which renders `App.js`. The `App` component manages a simple state toggle:

```
showHome = false → Shows Homepage (landing page)
showHome = true  → Shows Home (chat interface)
```

Navigation is controlled by the `Navbar` component, which calls `setShowHome()`.

> [!NOTE]
> There is a small quirk in the current code: `Homepage`'s `onButtonClick` is set to `console.log('Clicked')` instead of `() => setShowHome(true)`. This means the "Meet your SQL Assistant" button on the homepage **doesn't actually navigate** to the chat page. Navigation only works via the Navbar's "SQL Generator" button.

### 6.2 The Landing Page (Homepage)

**File:** [Homepage.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/components/Homepage.js)

This is a visually animated landing page using **framer-motion**. It features:
- A **clip-path wipe animation** that reveals the consultation image from left to right
- **Slide-in text** with staggered delays
- A **spring-animated button** that bounces on hover/click
- An **IntersectionObserver** that triggers animations when the content scrolls into view

### 6.3 The Main Chat Interface (Home.js) — The Most Important Frontend File

**File:** [Home.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/components/Home.js)

This ~936-line file is the **core of the frontend**. The top half (lines 1-464) is commented-out old code. The active code starts at **line 468**.

#### State Variables:

```javascript
query          // The text the user is currently typing
sqlDialect     // "Standard" | "Spark" | "Trino"
chatHistory    // Array of all messages [{sender, text, mode}, ...]
isLoading      // true when waiting for API response
activeMode     // "SQL Chat" | "File Analysis"
showIde        // true when SQL IDE is visible
feedbackData   // Array of all feedback submitted
ideQuery       // Query to pre-fill in the SQL IDE
```

#### The Message Flow in `handleSendMessage()`:

This is the most complex function. Here's what happens when a user presses "Send":

```
User presses Send
         ↓
1. Add user message to chatHistory
         ↓
2. Call findSimilarQuery(query)
   → POST /api/find-similar-query
   → Searches approved_queries table using embeddings
         ↓
   Found (similarity ≥ 85%)? 
     YES → Show the stored query + similarity score → DONE
     NO  → Continue ↓
         ↓
3. Call findSimilarFeedback(query)
   → POST /api/find-similar-feedback  
   → Searches feedback history
         ↓
   Found?
     YES → Show the similar previous interaction → DONE
     NO  → Continue ↓
         ↓
4. Call /api/chat with the query
   → Gemini AI generates a fresh SQL query
   → Add bot response to chatHistory → DONE
```

> [!IMPORTANT]
> This three-step cascade is the **feedback loop in action**. The system first tries to find an approved query, then similar feedback, and only as a last resort calls the AI. This saves API calls and improves accuracy over time.

#### The Feedback Flow in `handleFeedback()`:

```
User clicks 👍 or 👎
         ↓
1. Store feedback in local state (feedbackData)
         ↓
2. POST /api/feedback → Store in feedback.db
         ↓
3. Was it 👍 (positive)?
   YES → POST /api/store-approved-query
         → Generates embedding for the prompt
         → Stores prompt + SQL + embedding in approved_queries table
   NO  → POST /api/chat with feedback="no"
         → Triggers the alternative prompt in chatbot.py
         → Shows "Revised Query:" in chat
```

#### The Execute Button:

When a user clicks "Execute" on a bot's SQL response:
1. The SQL is extracted from the response text using a regex
2. The SQL IDE opens with that query pre-filled
3. The user can run it against the uploaded database

### 6.4 The SQL IDE

**File:** [SqlIde.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/components/SqlIde.js)

The IDE has three panels:

| Panel | What It Shows |
|-------|-------------|
| **Schema Panel** (left) | Lists all tables and their columns from the uploaded database |
| **Query Editor** (top right) | Monaco Editor with SQL syntax highlighting |
| **Results Panel** (bottom right) | Table showing query results |

Key features:
- Uses **Monaco Editor** (same editor as VS Code) for SQL editing
- Auto-refreshes schema after DDL queries (CREATE, ALTER, DROP)
- Fetches schema from `/api/get-schema` on mount

### 6.5 The Feedback Component

**File:** [Feedback.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/components/Feedback.js)

A simple component with two buttons (👍 Yes / 👎 No). It passes three things back to the parent:
- `isCorrect` (boolean) — was the response helpful?
- `query` — the user's original question
- `response` — the bot's SQL response

### 6.6 The Navbar

**File:** [Navbar.js](file:///d:/AskQL/Feedback%20Implmentation/ROUND1_SQL/askql/html/askql_project/frontend/src/components/Navbar.js)

Contains:
- **Brand logo + title** ("AskQL: TEXT TO SQL GENERATOR")
- **SQL Generator** button → navigates to the chat interface
- **Legal dropdown** → placeholder links (not functional)
- **Sign Up / Login** → placeholder links (not functional)

---

## 7. The Feedback System — The Core Innovation

This is what makes AskQL special compared to a basic "text-to-SQL" tool. Here's the complete feedback lifecycle:

### 7.1 The Feedback Database Schema

The `feedback.db` SQLite database contains two tables:

**Table: `feedback`**
```sql
CREATE TABLE feedback (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    query TEXT,           -- The user's original question
    response TEXT,        -- The AI-generated SQL
    is_correct INTEGER,   -- 1 = positive, 0 = negative
    timestamp TEXT        -- When the feedback was given
);
```

**Table: `approved_queries`**
```sql
CREATE TABLE approved_queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    prompt TEXT NOT NULL UNIQUE,        -- The user's question
    sql_query TEXT NOT NULL,            -- The correct SQL query
    prompt_embedding BLOB NOT NULL,    -- 384-dimensional vector (binary)
    usage_count INTEGER DEFAULT 1,      -- How many times this was reused
    last_used DATETIME DEFAULT CURRENT_TIMESTAMP
);
```

### 7.2 How Semantic Similarity Search Works

```
New prompt: "show total number of employees"
                    ↓
Step 1: Convert to a 384-dim vector using SentenceTransformer
        → [0.12, -0.34, 0.56, ..., 0.78]
                    ↓
Step 2: Load ALL stored embeddings from approved_queries
                    ↓
Step 3: For each stored embedding, compute cosine similarity
        
        cosine_similarity = (A · B) / (|A| × |B|)
        
        Stored: "count all employees"    → similarity = 0.92 ✅
        Stored: "list product names"     → similarity = 0.31 ❌
        Stored: "total employee count"   → similarity = 0.88 ✅
                    ↓
Step 4: If best similarity ≥ 0.85 (threshold), return the stored SQL
        → Returns "count all employees" query with 92% confidence
```

> [!TIP]
> **Cosine similarity** measures the angle between two vectors. A score of 1.0 means identical, 0.0 means completely unrelated. The threshold of 0.85 is a balance between precision (not returning wrong queries) and recall (finding relevant queries even when phrased differently).

### 7.3 The Learning Loop Visualized

```
FIRST USER asks: "how many employees?"
    → Gemini generates: SELECT COUNT(*) FROM employees;
    → User clicks 👍
    → Stored in approved_queries with embedding

SECOND USER asks: "count of all employees?"
    → System finds approved query (similarity: 0.91)
    → Returns stored SQL directly (no AI call needed!)
    → Faster response + guaranteed correct answer
```

---

## 8. Data Flow — How a User Request Travels

### Flow 1: SQL Chat (Normal Query)

```
┌──────────┐     POST /api/chat        ┌──────────┐
│ React UI │ ──────────────────────────→│ Flask    │
│ Home.js  │     {message, mode,       │ app.py   │
│          │      dialect}              │          │
└──────────┘                            └────┬─────┘
                                             │
                                    ChatBot.respond()
                                             │
                                    ┌────────▼────────┐
                                    │  Google Gemini   │
                                    │  1.5 Pro         │
                                    │  (via LangChain) │
                                    └────────┬────────┘
                                             │
                                    SQL Query + Explanation
                                             │
┌──────────┐     {status, response}  ┌───────▼──────┐
│ React UI │ ←───────────────────────│ Flask        │
│ displays │     JSON response       │ returns JSON │
│ in chat  │                         │              │
└──────────┘                         └──────────────┘
```

### Flow 2: File Upload + Analysis

```
User selects employees.csv
         ↓
POST /api/upload (multipart/form-data)
         ↓
Flask saves to uploads/employees.csv
         ↓
pandas reads CSV → df = pd.read_csv(...)
         ↓
SQLAlchemy creates table: df.to_sql("employees", engine)
         ↓
Now data/uploaded_files_sqldb.db has an "employees" table
         ↓
User asks: "How many employees earn over 50000?"
         ↓
POST /api/chat {message, mode: "File Analysis"}
         ↓
LangChain creates SQL chain with the uploaded DB
         ↓
Gemini generates: SELECT COUNT(*) FROM employees WHERE salary > 50000
         ↓
Query is EXECUTED on the actual database
         ↓
Results returned: {sql_query, results: "42", explanation}
```

### Flow 3: SQL IDE Execution

```
User writes SQL in Monaco Editor
         ↓
Clicks "Execute"
         ↓
POST /api/execute-sql {query: "SELECT * FROM employees LIMIT 10"}
         ↓
SQLAlchemy connects to uploaded_files_sqldb.db
         ↓
Executes the raw SQL query
         ↓
Returns column names + rows as JSON
         ↓
Rendered as HTML table in the IDE
```

---

## 9. API Endpoints Reference

### POST `/api/chat`
**Purpose:** Generate SQL from natural language  
**Request Body:**
```json
{
  "message": "Show me all customers",
  "app_functionality": "SQL Chat",  
  "sql_dialect": "Standard",
  "feedback": "no"  // Optional, triggers regeneration
}
```
**Response:**
```json
{
  "status": "success",
  "response": "SQL Query:\nSELECT * FROM customers;\n\nExplanation:\nThis query retrieves..."
}
```

---

### POST `/api/execute-sql`
**Purpose:** Execute raw SQL on uploaded data  
**Request:** `{"query": "SELECT * FROM employees LIMIT 5"}`  
**Response:**
```json
{
  "status": "success",
  "results": [
    {"id": 1, "name": "John", "salary": 60000},
    {"id": 2, "name": "Jane", "salary": 75000}
  ]
}
```

---

### POST `/api/upload`
**Purpose:** Upload CSV/XLSX files  
**Request:** `multipart/form-data` with field `files`  
**Response:** `{"status": "success", "files": ["employees.csv"], "messages": [...]}`

---

### GET `/api/get-schema`
**Purpose:** Get database table/column structure  
**Response:**
```json
{
  "status": "success",
  "schema": [
    {
      "name": "employees",
      "columns": [
        {"name": "id", "type": "INTEGER"},
        {"name": "name", "type": "TEXT"}
      ]
    }
  ]
}
```

---

### POST `/api/feedback`
**Purpose:** Store user feedback  
**Request:** `{"query": "...", "response": "...", "isCorrect": true, "timestamp": "..."}`

---

### POST `/api/store-approved-query`
**Purpose:** Save a positively-rated query with its embedding  
**Request:** `{"prompt": "...", "sql_query": "..."}`

---

### POST `/api/find-similar-query`
**Purpose:** Find semantically similar approved queries  
**Request:** `{"prompt": "...", "threshold": 0.85}`  
**Response (found):** `{"status": "success", "found": true, "prompt": "...", "sql_query": "...", "similarity": 0.92}`  
**Response (not found):** `{"status": "success", "found": false}`

---

### GET `/api/feedback-stats`
**Purpose:** Analytics dashboard data  
**Response:**
```json
{
  "status": "success",
  "total_feedback": 42,
  "positive_feedback": 35,
  "negative_feedback": 7,
  "top_queries": [{"query": "count employees", "count": 5}]
}
```

---

## 10. How to Set Up and Run the Project

### Prerequisites
- **Python 3.9+** installed
- **Node.js 18+** installed
- **A Google API Key** for Gemini (get from https://aistudio.google.com/apikey)

### Step 1: Backend Setup

```bash
# Navigate to backend
cd askql_project/backend

# Create virtual environment
python -m venv venv
# On Windows:
venv\Scripts\activate
# On Linux/Mac:
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
# You also need these (missing from requirements.txt):
pip install sentence-transformers scikit-learn google-generativeai langchain-google-genai

# Configure API key
# Edit backend/.env and set:
# GOOGLE_API_KEY=your_actual_api_key_here
```

### Step 2: Start the Backend

```bash
cd backend/src
python app.py
# Server starts on http://localhost:5000
```

### Step 3: Frontend Setup

```bash
# Navigate to frontend (in a new terminal)
cd askql_project/frontend

# Install dependencies
npm install

# Start development server
npm start
# Opens http://localhost:3000 in your browser
```

### Step 4: Using the App

1. Open `http://localhost:3000` in your browser
2. Click "SQL Generator" in the navbar
3. Choose a mode (SQL Chat or File Analysis)
4. If File Analysis: upload a CSV/XLSX file first
5. Type your question and press Send
6. Review the generated SQL
7. Click 👍 or 👎 to give feedback
8. Click "Execute" to open it in the SQL IDE

> [!CAUTION]
> The `GOOGLE_API_KEY` in the checked-in `.env` file may be revoked or have usage limits. Always use your own key.

---

## 11. Common Issues and Debugging

### Issue: "CORS error" in browser console
**Cause:** Backend isn't running or is on the wrong port  
**Fix:** Make sure Flask is running on port 5000 (`python app.py`)

### Issue: "No database available" error
**Cause:** No files have been uploaded yet  
**Fix:** Switch to "File Analysis" mode and upload a CSV/XLSX file first

### Issue: "Error: Missing required field"
**Cause:** Frontend is sending wrong field names  
**Fix:** Check that the fetch call in Home.js matches what app.py expects

### Issue: SentenceTransformer takes long to load
**Cause:** First run downloads the model (~90MB)  
**Fix:** This is normal. Subsequent starts are faster because the model is cached

### Issue: Frontend builds but shows blank page
**Cause:** Often a JavaScript import error  
**Fix:** Check the browser console (F12) for errors. Common cause: missing asset files in `src/assets/`

### Issue: `pyprojroot` can't find config
**Cause:** The `here()` function looks for a project root marker (like `.git`)  
**Fix:** Make sure you're running from the `backend/src` directory and that `.git` exists in the project root

---

## 12. Key Concepts You Must Understand

### 12.1 What is LangChain?

LangChain is a framework that makes it easy to build applications with LLMs. In this project, it's used for:
- **ChatGoogleGenerativeAI** — A wrapper around Google Gemini that provides a standard interface
- **create_sql_query_chain** — A chain that takes a database schema + question → generates a valid SQL query
- **SQLDatabase** — Connects LangChain to a SQLite database for schema inspection
- **QuerySQLDataBaseTool** — Executes generated SQL queries

### 12.2 What is an Embedding?

An embedding is a way to represent text as a list of numbers (a vector). Similar texts have similar vectors. Example:

```
"how many employees"  → [0.12, -0.34, 0.56, ..., 0.78]  (384 numbers)
"count of employees"  → [0.13, -0.32, 0.57, ..., 0.77]  (very similar!)
"best pizza recipe"   → [-0.45, 0.89, -0.12, ..., 0.03] (very different!)
```

The `all-MiniLM-L6-v2` model produces 384-dimensional vectors. These are stored as binary BLOBs in SQLite.

### 12.3 What is Cosine Similarity?

It measures how similar two vectors are. Think of it as measuring the "angle" between two arrows:
- **1.0** = same direction (identical meaning)
- **0.0** = perpendicular (unrelated)
- **-1.0** = opposite direction (opposite meaning)

### 12.4 What is RAG (Retrieval Augmented Generation)?

RAG is a technique where you:
1. **Retrieve** relevant information from a database
2. **Augment** the AI prompt with that information
3. **Generate** a response based on the combined context

In AskQL, this is used in the "File Analysis" mode: the uploaded data's schema is retrieved and added to the prompt so Gemini knows what tables and columns are available.

### 12.5 Flask vs FastAPI

Both are Python web frameworks. Flask is used as the **primary** server in this project. FastAPI exists as an alternative (`fastapi_app.py`). Key difference: FastAPI is async and has built-in request validation, but Flask was chosen here because it's simpler and the original project used Gradio (which is built on Flask).

### 12.6 What is the Monaco Editor?

It's the same editor that powers **Visual Studio Code**, packaged as a React component. In the SQL IDE, it provides:
- SQL syntax highlighting
- Line numbers
- Auto-formatting
- Word wrap
- Scrollbars

### 12.7 The SQLite Database Ecosystem

The project uses **two separate** SQLite databases:

| Database | Purpose | Created By |
|----------|---------|-----------|
| `feedback.db` | Stores feedback + approved queries | `app.py` (auto-created on first feedback) |
| `data/uploaded_files_sqldb.db` | Stores user's uploaded CSV/XLSX data as SQL tables | `upload_file.py` (when user uploads files) |

> [!IMPORTANT]
> These are NOT the same database. `feedback.db` is the learning/memory system. `uploaded_files_sqldb.db` is the user's actual data.

---

> **Final Note for your colleague:** If you've read this entire document, you now understand the project better than 99% of people who would look at this code. The key files to focus on are `app.py` (backend), `chatbot.py` (AI logic), and `Home.js` (frontend). Everything else is either configuration, utilities, or styling. Good luck! 🚀
