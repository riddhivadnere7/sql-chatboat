
import { useState } from 'react';
import Navbar from './components/Navbar';
import Homepage from './components/Homepage';
import Home from './components/Home';

function App() {
  const [showHome, setShowHome] = useState(false);

  return (
    <div style={{ minHeight: '100vh' }}>
      {/* Pass setShowHome to Navbar */}
      <Navbar setCurrentPage={setShowHome} />
      
      {showHome ? (
        <Home onBack={() => setShowHome(false)} />
      ) : (
        /*<Homepage onButtonClick={() => setShowHome(true)} /> */
        <Homepage onButtonClick={() => console.log('Clicked')} />
      )}
    </div>
  );
}

export default App;