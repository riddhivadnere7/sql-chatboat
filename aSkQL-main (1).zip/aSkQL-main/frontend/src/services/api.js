import axios from 'axios';

const API = axios.create({
  baseURL: 'http://localhost:8000',
  headers: {
    'Content-Type': 'application/json'
  }
});

export const sendMessage = (message, mode = 'SQL Chat', dialect = 'Standard') => {
  return API.post('/api/chat', { message, mode, dialect });
};

export const uploadFiles = (files) => {
  const formData = new FormData();
  files.forEach(file => formData.append('files', file));
  
  return axios.post('http://localhost:8000/api/upload', formData, {
    headers: {
      'Content-Type': 'multipart/form-data'
    }
  });
};