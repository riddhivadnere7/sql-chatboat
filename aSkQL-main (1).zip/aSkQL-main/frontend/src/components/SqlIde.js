// import React, { useState, useRef, useEffect } from 'react';
// import { FaPlay } from 'react-icons/fa';
// import './SqlIde.css';

// const SqlIde = ({ onExecuteQuery, isDisabled }) => {
//   const [query, setQuery] = useState('SELECT * FROM users;');
//   const [results, setResults] = useState([]);
//   const [tables, setTables] = useState([]);
//   const [isSchemaLoading, setIsSchemaLoading] = useState(false);
//   const [tables, setTables] = useState([
//     {
//       name: 'users',
//       columns: [
//         { name: 'id', type: 'INTEGER' },
//         { name: 'name', type: 'TEXT' },
//         { name: 'email', type: 'TEXT' }
//       ]
//     },
//     {
//       name: 'products',
//       columns: [
//         { name: 'id', type: 'INTEGER' },
//         { name: 'title', type: 'TEXT' }
//       ]
//     }
//   ]);

//     useEffect(() => {
//     if (!isDisabled) {
//       fetchDatabaseSchema();
//     }
//   }, [isDisabled]);

//   const fetchDatabaseSchema = async () => {
//     setIsSchemaLoading(true);
//     try {
//       const response = await fetch('http://localhost:5000/api/get-schema');
//       const data = await response.json();
//       if (data.status === "success") {
//         setTables(data.schema);
//       }
//     } catch (error) {
//       console.error("Error fetching schema:", error);
//     } finally {
//       setIsSchemaLoading(false);
//     }
//   };

//   const executeQuery = async () => {
//     if (!query.trim() || isDisabled) return;
    
//     try {
//       const response = await fetch('http://localhost:5000/api/execute-sql', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ query }),
//       });
//       const data = await response.json();
      
//       if (data.status === "success") {
//         setResults(data.results || []);
//         // Refresh schema after executing DDL queries
//         if (query.trim().toUpperCase().startsWith('CREATE') || 
//             query.trim().toUpperCase().startsWith('ALTER') || 
//             query.trim().toUpperCase().startsWith('DROP')) {
//           fetchDatabaseSchema();
//         }
//       } else {
//         setResults([{ error: data.message || "Execution failed" }]);
//       }
//     } catch (error) {
//       setResults([{ error: "Network error: " + error.message }]);
//     }
//   };

//   return (
//     <div className="sql-ide-container">
//       <div className="schema-panel">
//         <div className="schema-header">
//           <h3>Database Schema</h3>
//           <button 
//             onClick={fetchDatabaseSchema}
//             className="refresh-schema"
//             disabled={isSchemaLoading}
//           >
//             {isSchemaLoading ? "Refreshing..." : "Refresh"}
//           </button>
//         </div>
//         {isSchemaLoading ? (
//           <div className="schema-loading">Loading schema...</div>
//         ) : (
//           tables.map(table => (
//             <div key={table.name} className="table-schema">
//               <strong>{table.name}</strong>
//               <ul>
//                 {table.columns.map(col => (
//                   <li key={col.name}>
//                     {col.name} <span className="column-type">({col.type})</span>
//                   </li>
//                 ))}
//               </ul>
//             </div>
//           ))
//         )}
//       </div>

//       <div className="query-panel">
//         <div className="query-input-container">
//           <textarea
//             value={query}
//             onChange={(e) => setQuery(e.target.value)}
//             className="query-input"
//             disabled={isDisabled}
//           />
//           <button 
//             onClick={executeQuery}
//             className="execute-button"
//             disabled={isDisabled}
//           >
//             <FaPlay /> Execute
//           </button>
//         </div>

//         <div className="results-panel">
//           <h3>Query Results</h3>
//           {results.length > 0 ? (
//             <div className="results-table">
//               <table>
//                 <thead>
//                   <tr>
//                     {Object.keys(results[0]).map(col => (
//                       <th key={col}>{col}</th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {results.map((row, i) => (
//                     <tr key={i}>
//                       {Object.values(row).map((val, j) => (
//                         <td key={j}>{val}</td>
//                       ))}
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//               <div className="results-count">
//                 Showing {results.length} row{results.length !== 1 ? 's' : ''}
//               </div>
//             </div>
//           ) : (
//             <div className="no-results">
//               {isDisabled ? 'Upload files to enable querying' : 'Results will appear here'}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SqlIde;

// import React, { useState, useEffect } from 'react';
// import { FaPlay, FaSync } from 'react-icons/fa';
// import './SqlIde.css';

// const SqlIde = ({ onExecuteQuery, isDisabled }) => {
//   const [query, setQuery] = useState('SELECT * FROM users;');
//   const [results, setResults] = useState([]);
//   const [tables, setTables] = useState([]);
//   const [isSchemaLoading, setIsSchemaLoading] = useState(false);

//   // Fetch schema when component mounts or when disabled status changes
//   useEffect(() => {
//     if (!isDisabled) {
//       fetchDatabaseSchema();
//     }
//   }, [isDisabled]);

//   const fetchDatabaseSchema = async () => {
//     setIsSchemaLoading(true);
//     try {
//       const response = await fetch('http://localhost:5000/api/get-schema');
//       const data = await response.json();
//       if (data.status === "success") {
//         setTables(data.schema);
//       }
//     } catch (error) {
//       console.error("Error fetching schema:", error);
//     } finally {
//       setIsSchemaLoading(false);
//     }
//   };

//   const executeQuery = async () => {
//     if (!query.trim() || isDisabled) return;
    
//     try {
//       const response = await fetch('http://localhost:5000/api/execute-sql', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ query }),
//       });
//       const data = await response.json();
      
//       if (data.status === "success") {
//         setResults(data.results || []);
//         // Refresh schema after executing DDL queries
//         if (query.trim().toUpperCase().match(/^(CREATE|ALTER|DROP|RENAME|TRUNCATE)/)) {
//           fetchDatabaseSchema();
//         }
//       } else {
//         setResults([{ error: data.message || "Execution failed" }]);
//       }
//     } catch (error) {
//       setResults([{ error: "Network error: " + error.message }]);
//     }
//   };

//   return (
//     <div className="sql-ide-container">
//       <div className="schema-panel">
//         <div className="schema-header">
//           <h3>Database Schema</h3>
//           <button 
//             onClick={fetchDatabaseSchema}
//             className="refresh-schema"
//             disabled={isSchemaLoading || isDisabled}
//           >
//             <FaSync className={isSchemaLoading ? "spin-icon" : ""} />
//           </button>
//         </div>
//         {isSchemaLoading ? (
//           <div className="schema-loading">Loading schema...</div>
//         ) : tables.length > 0 ? (
//           tables.map(table => (
//             <div key={table.name} className="table-schema">
//               <strong>{table.name}</strong>
//               <ul>
//                 {table.columns.map(col => (
//                   <li key={col.name}>
//                     {col.name} <span className="column-type">({col.type})</span>
//                   </li>
//                 ))}
//               </ul>
//             </div>
//           ))
//         ) : (
//           <div className="no-tables">No tables found</div>
//         )}
//       </div>

//       <div className="query-panel">
//         <div className="query-input-container">
//           <textarea
//             value={query}
//             onChange={(e) => setQuery(e.target.value)}
//             className="query-input"
//             disabled={isDisabled}
//           />
//           <button 
//             onClick={executeQuery}
//             className="execute-button"
//             disabled={isDisabled}
//           >
//             <FaPlay /> Execute
//           </button>
//         </div>

//         <div className="results-panel">
//           <h3>Query Results</h3>
//           {results.length > 0 ? (
//             <div className="results-table">
//               <table>
//                 <thead>
//                   <tr>
//                     {Object.keys(results[0]).map(col => (
//                       <th key={col}>{col}</th>
//                     ))}
//                   </tr>
//                 </thead>
//                 <tbody>
//                   {results.map((row, i) => (
//                     <tr key={i}>
//                       {Object.values(row).map((val, j) => (
//                         <td key={j}>{val}</td>
//                       ))}
//                     </tr>
//                   ))}
//                 </tbody>
//               </table>
//               <div className="results-count">
//                 Showing {results.length} row{results.length !== 1 ? 's' : ''}
//               </div>
//             </div>
//           ) : (
//             <div className="no-results">
//               {isDisabled ? 'Upload files to enable querying' : 'Results will appear here'}
//             </div>
//           )}
//         </div>
//       </div>
//     </div>
//   );
// };

// export default SqlIde;

import React, { useState, useEffect } from 'react';
import { FaPlay, FaSync } from 'react-icons/fa';
import Editor from '@monaco-editor/react';
import './SqlIde.css';

const SqlIde = ({ onExecuteQuery, isDisabled, initialQuery }) => {
  const [query, setQuery] = useState(initialQuery || 'SELECT * FROM users;');
  const [results, setResults] = useState([]);
  const [tables, setTables] = useState([]);
  const [isSchemaLoading, setIsSchemaLoading] = useState(false);

  useEffect(() => {
    if (initialQuery) {
      setQuery(initialQuery);
    }
  }, [initialQuery]);

  useEffect(() => {
    fetchDatabaseSchema();
  }, []);

  const fetchDatabaseSchema = async () => {
    setIsSchemaLoading(true);
    try {
      const response = await fetch('http://localhost:5000/api/get-schema');
      const data = await response.json();
      if (data.status === "success") {
        setTables(data.schema);
      }
    } catch (error) {
      console.error("Error fetching schema:", error);
    } finally {
      setIsSchemaLoading(false);
    }
  };

  const executeQuery = async () => {
    if (!query.trim() || isDisabled) return;
    
    try {
      const response = await fetch('http://localhost:5000/api/execute-sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const data = await response.json();
      
      if (data.status === "success") {
        setResults(data.results || []);
        if (query.trim().toUpperCase().match(/^(CREATE|ALTER|DROP|RENAME|TRUNCATE)/)) {
          fetchDatabaseSchema();
        }
      } else {
        setResults([{ error: data.message || "Execution failed" }]);
      }
    } catch (error) {
      setResults([{ error: "Network error: " + error.message }]);
    }
  };

  return (
    <div className="sql-ide-container">
      <div className="schema-panel">
        <div className="schema-header">
          <h3>Database Schema</h3>
          <button 
            onClick={fetchDatabaseSchema}
            className="refresh-schema"
            disabled={isSchemaLoading}
          >
            <FaSync className={isSchemaLoading ? "spin-icon" : ""} />
          </button>
        </div>
        {isSchemaLoading ? (
          <div className="schema-loading">Loading schema...</div>
        ) : tables.length > 0 ? (
          tables.map(table => (
            <div key={table.name} className="table-schema">
              <strong>{table.name}</strong>
              <ul>
                {table.columns.map(col => (
                  <li key={col.name}>
                    {col.name} <span className="column-type">({col.type})</span>
                  </li>
                ))}
              </ul>
            </div>
          ))
        ) : (
          <div className="no-tables">No tables found</div>
        )}
      </div>

      <div className="query-panel">
        <div className="query-input-container">
          <Editor
            height="200px"
            defaultLanguage="sql"
            value={query}
            onChange={(value) => setQuery(value || '')}
            options={{
              minimap: { enabled: false },
              scrollBeyondLastLine: false,
              fontSize: 14,
              wordWrap: 'on',
              automaticLayout: true,
              lineNumbers: 'on',
              roundedSelection: true,
              scrollbar: {
                vertical: 'auto',
                horizontal: 'auto'
              },
              theme: 'vs',
              renderWhitespace: 'none',
              folding: true,
              lineDecorationsWidth: 10,
              formatOnPaste: true,
            }}
          />
          <button 
            onClick={executeQuery}
            className="execute-button"
            disabled={!query.trim()} // Only disable if query is empty
          >
            <FaPlay /> Execute
          </button>
        </div>

        <div className="results-panel">
          <h3>Query Results</h3>
          {results.length > 0 ? (
            <div className="results-table">
              <table>
                <thead>
                  <tr>
                    {Object.keys(results[0]).map(col => (
                      <th key={col}>{col}</th>
                    ))}
                  </tr>
                </thead>
                <tbody>
                  {results.map((row, i) => (
                    <tr key={i}>
                      {Object.values(row).map((val, j) => (
                        <td key={j}>{val}</td>
                      ))}
                    </tr>
                  ))}
                </tbody>
              </table>
              <div className="results-count">
                Showing {results.length} row{results.length !== 1 ? 's' : ''}
              </div>
            </div>
          ) : (
            <div className="no-results">
              {isDisabled ? 'Upload files to enable querying' : 'Results will appear here'}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default SqlIde;