export default function Test() {
    return <h1 style={{ color: 'red' }}>TEST COMPONENT IS RENDERING</h1>;
  }