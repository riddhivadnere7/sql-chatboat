import React, { useEffect, useRef, useState } from "react";
import { motion } from 'framer-motion';
import Navbar from "./Navbar";
import './Homepage.css';
import consultationImage from '../assets/consultation.jpg';

const Homepage = ({ onButtonClick }) => {
  const [inView, setInView] = useState(false);
  const [isLoaded, setIsLoaded] = useState(false);
  const ref = useRef();
  
  useEffect(() => {
    const observer = new IntersectionObserver(
      ([entry]) => setInView(entry.isIntersecting),
      { threshold: 0.1 }
    );
    if (ref.current) observer.observe(ref.current);
    
    // Set loaded after a short delay to trigger opacity transition
    const timer = setTimeout(() => setIsLoaded(true), 100);
    
    return () => {
      observer.disconnect();
      clearTimeout(timer);
    };
  }, []);

  return (
    <div className={`homepage-container ${isLoaded ? 'loaded' : ''}`}>
      <Navbar />
      <div className="content-wrapper" ref={ref}>
        {/* Wipe Animation Container */}
        <motion.div
          className="image-section"
          initial={{ clipPath: 'polygon(0 0, 0 0, 0 100%, 0% 100%)' }}
          animate={inView ? { clipPath: 'polygon(0 0, 100% 0, 100% 100%, 0% 100%)' } : {}}
          transition={{ duration: 1.2 }}
        >
          {/* Nested Motion for the image */}
          <motion.div 
            initial={{ x: -100, opacity: 0 }}
            animate={inView ? { x: 0, opacity: 1 } : {}}
            transition={{ duration: 0.8, delay: 0.3 }}
          >
            <div className="image-wrapper">
              <motion.img
                src={consultationImage}
                alt="Business consultation"
                className="content-image"
                initial={{ scale: 1.1 }}
                animate={inView ? { scale: 1 } : {}}
                transition={{ duration: 1.2, delay: 0.5 }}
              />
            </div>
          </motion.div>
        </motion.div>

        {/* Text Section */}
        <motion.div
          className="text-section"
          initial={{ x: 50, opacity: 0 }}
          animate={inView ? { x: 0, opacity: 1 } : {}}
          transition={{ duration: 0.8, delay: 0.2 }}
        >
          <motion.h1
            initial={{ y: 20, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.4 }}
          >
            AskQL: AI-Powered SQL Assistant
          </motion.h1>
          
          <motion.p
            initial={{ y: 20, opacity: 0 }}
            animate={inView ? { y: 0, opacity: 1 } : {}}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            Custom software solutions to help your business succeed.
          </motion.p>
          
          <motion.button
            onClick={onButtonClick}
            className="consultation-button"
            initial={{ scale: 0.8, opacity: 0 }}
            animate={inView ? { scale: 1, opacity: 1 } : {}}
            transition={{ type: "spring", stiffness: 300, delay: 0.9 }}
            whileHover={{ scale: 1.05 }}
            whileTap={{ scale: 0.95 }}
          >
            Meet your SQL Assistant
          </motion.button>
        </motion.div>
      </div>
    </div>
  );
};

export default Homepage;