import React, { useState } from 'react';
import { FaUpload } from 'react-icons/fa';

const FileUpload = ({ onUpload, disabled }) => {
  const [files, setFiles] = useState(null);

  const handleUpload = async () => {
    if (!files || files.length === 0 || disabled) return;

    const formData = new FormData();
    files.forEach(file => {
      formData.append('files', file);  // Must match Flask's expected field name
    });

    try {
      const response = await fetch('/api/upload', {
        method: 'POST',
        body: formData,
      });
      const data = await response.json();
      
      if (data.status === "success") {
        // Transform response to match expected format
        const transformedData = {
          chatbot: data.messages.map(msg => ["bot", msg])
        };
        onUpload(transformedData);
      } else {
        throw new Error(data.message || "Upload failed");
      }
    } catch (error) {
      console.error('Upload failed:', error);
      onUpload({
        chatbot: [["system", `Error: ${error.message}`]]
      });
    }
  };

  return (
    <div className="file-upload-container">
      <label className="upload-label">
        <FaUpload className="upload-icon" />
        <span>Select Files</span>
        <input 
          type="file" 
          multiple 
          onChange={(e) => setFiles(Array.from(e.target.files))}
          accept=".csv,.xlsx"
          disabled={disabled}
          style={{ display: 'none' }}
        />
      </label>
      
      {files && (
        <div className="file-list">
          <ul>
            {files.map((file, index) => (
              <li key={index}>{file.name}</li>
            ))}
          </ul>
          <button 
            onClick={handleUpload} 
            disabled={disabled || !files}
            className="upload-button"
          >
            Upload Files
          </button>
        </div>
      )}
    </div>
  );
};

export default FileUpload;