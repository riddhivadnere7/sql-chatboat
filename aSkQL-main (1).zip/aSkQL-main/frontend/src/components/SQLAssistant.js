import React, { useState } from "react";
import axios from "axios";
import { ToastContainer, toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import Header from "./Header"; // Use the Header component
import { FaCopy } from "react-icons/fa";

const SQLAssistant = () => {
  const [query, setQuery] = useState("");
  const [sqlResponse, setSqlResponse] = useState("");

  const handleQuerySubmit = async () => {
    if (!query.trim()) {
      toast.error("Please enter a query!");
      return;
    }

    try {
      const response = await axios.post("http://localhost:5000/generate-sql", {
        query,
      });
      setSqlResponse(response.data.sql);
      toast.success("SQL query generated successfully!");
    } catch (error) {
      toast.error("Error generating SQL!");
    }
  };

  const handleClear = () => {
    setQuery("");
    setSqlResponse("");
  };

  const handleCopy = () => {
    if (sqlResponse) {
      navigator.clipboard.writeText(sqlResponse);
      toast.success("Copied to clipboard!");
    }
  };

  return (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gray-100 p-4">

      {/* Query Input Box */}
      <div className="w-full max-w-lg mb-4">
        <h2 className="text-xl font-bold">Enter Natural Language Query</h2>
        <textarea
          className="w-full p-3 bg-gray-200 rounded mt-2 h-28"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Example: Show all customers who purchased in the last month..."
        />
      </div>

      {/* Buttons */}
      <div className="flex gap-4 mb-4">
        <button className="bg-black text-white px-6 py-2 rounded" onClick={handleQuerySubmit}>
          Generate SQL
        </button>
        <button className="bg-gray-500 text-white px-6 py-2 rounded" onClick={handleClear}>
          Clear
        </button>
      </div>

      {/* SQL Output Box */}
      {sqlResponse && (
        <div className="w-full max-w-lg bg-gray-200 p-4 rounded relative">
          <h3 className="font-semibold">Generated SQL Query:</h3>
          <pre>{sqlResponse}</pre>
          <FaCopy className="absolute top-2 right-2 cursor-pointer" onClick={handleCopy} />
        </div>
      )}

      <ToastContainer />
    </div>
  );
};

export default SQLAssistant;
