import React from "react";
import { FaDatabase } from "react-icons/fa";
import "../App.css";

const Header = () => {
  return (
    <header className="header w-full py-6 bg-gradient-to-r from-blue-600 to-purple-600 shadow-md">
      <div className="container mx-auto text-center">
        <div className="flex items-center justify-center mb-2">
          <FaDatabase className="text-white text-3xl mr-3" />
          <h1 className="text-4xl md:text-5xl font-bold text-white">
            ""
          </h1>
        </div>
      </div>
    </header>
  );
};

export default Header;