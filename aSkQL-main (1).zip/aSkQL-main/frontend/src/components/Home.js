

// import React, { useState, useRef, useEffect } from "react";
// import { FaCopy, FaFileUpload, FaDatabase, FaFileAlt, FaTrash, FaCode, FaPlay } from "react-icons/fa";
// import "./Home.css";
// import SqlIde from './SqlIde';
// import Feedback from './Feedback';

// const Home = ({ onBack }) => {
//   const [query, setQuery] = useState("");
//   const [sqlDialect, setSqlDialect] = useState("Standard");
//   const [chatHistory, setChatHistory] = useState([]);
//   const [isLoading, setIsLoading] = useState(false);
//   const [activeMode, setActiveMode] = useState("SQL Chat");
//   const [showIde, setShowIde] = useState(false);
//   const [feedbackData, setFeedbackData] = useState([]);
//   const [ideQuery, setIdeQuery] = useState("");
//   const chatEndRef = useRef(null);

//   useEffect(() => {
//     scrollToBottom();
//   }, [chatHistory]);

//   const scrollToBottom = () => {
//     chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
//   };

//   const handleExecuteClick = (queryText) => {
//     const sqlMatch = queryText.match(/SQL Query:\n([\s\S]*?)(?=\n\nExplanation:|$)/);
//     const queryToExecute = sqlMatch ? sqlMatch[1].trim() : queryText;
    
//     setIdeQuery(queryToExecute);
//     setActiveMode("SQL Chat");
//     setShowIde(true);
//   };
//   const findSimilarFeedback = async (prompt) => {
//     try {
//       const response = await fetch('http://localhost:5000/api/find-similar-feedback', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           prompt: prompt,
//           threshold: 0.85 // Adjust as needed
//         }),
//       });
//       return await response.json();
//     } catch (error) {
//       console.error('Similarity search failed:', error);
//       return { status: "error" };
//     }
//   };

//   const handleFeedback = async (isCorrect, prompt, response) => {
//     const feedbackItem = {
//       query: prompt,
//       response: response,
//       isCorrect,
//       timestamp: new Date().toISOString()
//     };
    
//     setFeedbackData(prev => [...prev, feedbackItem]);
    
//     try {
//       // Send feedback to backend
//       await fetch('http://localhost:5000/api/feedback', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify(feedbackItem),
//       });
  
//       // If feedback is positive, store as approved query
//       if (isCorrect && activeMode === "SQL Chat") {
//         await fetch('http://localhost:5000/api/store-approved-query', {
//           method: 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify({
//             prompt: prompt,
//             sql_query: response
//           }),
//         });
//       }
  
//       if (!isCorrect) {
//         // Regenerate query if feedback is negative
//         setIsLoading(true);
        
//         const regenResponse = await fetch('http://localhost:5000/api/chat', {
//           method: 'POST',
//           headers: { 'Content-Type': 'application/json' },
//           body: JSON.stringify({
//             message: prompt,
//             app_functionality: activeMode,
//             sql_dialect: sqlDialect
//           }),
//         });
        
//         const regenData = await regenResponse.json();
        
//         if (regenData.status === "success") {
//           const botMessage = { 
//             sender: 'bot', 
//             text: `Revised Query:\n${regenData.response}`,
//             mode: activeMode
//           };
//           setChatHistory(prev => [...prev, botMessage]);
//         }
//       }
//     } catch (error) {
//       console.error('Feedback error:', error);
//       setChatHistory(prev => [...prev, {
//         sender: 'system',
//         text: `Error: ${error.message}`,
//         mode: activeMode
//       }]);
//     } finally {
//       setIsLoading(false);
//     }
//   };
  
//   const executeQuery = async (query) => {
//     try {
//       const response = await fetch('http://localhost:5000/api/execute-sql', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ query }),
//       });
//       const data = await response.json();
//       if (data.status === "success") {
//         return data.results || [];
//       }
//       throw new Error(data.message || "Query execution failed");
//     } catch (error) {
//       setChatHistory(prev => [...prev, {
//         sender: 'system',
//         text: `SQL Error: ${error.message}`,
//         mode: activeMode
//       }]);
//       return [];
//     }
//   };
//   const findSimilarQuery = async (prompt) => {
//     try {
//       const response = await fetch('http://localhost:5000/api/find-similar-query', {
//         method: 'POST',
//         headers: { 'Content-Type': 'application/json' },
//         body: JSON.stringify({ 
//           prompt: prompt,
//           threshold: 0.85
//         }),
//       });
//       return await response.json();
//     } catch (error) {
//       console.error('Similarity search failed:', error);
//       return { status: "error" };
//     }
//   };

  

//   const handleSendMessage = async () => {
//     if (!query.trim()) return;
    
//     setIsLoading(true);
//     const userMessage = { sender: 'user', text: query, mode: activeMode };
//     setChatHistory(prev => [...prev, userMessage]);
    
//     try {
//       // First check for similar approved queries
//       const similarQuery = await findSimilarQuery(query);
      
//       if (similarQuery.status === "success" && similarQuery.found) {
//         const botMessage = { 
//           sender: 'bot', 
//           text: `Similar approved query found:\n${similarQuery.sql_query}\n\n[Similarity: ${(similarQuery.similarity * 100).toFixed(1)}%]`,
//           mode: activeMode
//         };
//         setChatHistory(prev => [...prev, botMessage]);
//       } else {
//         // If no approved query found, check for similar feedback
//         const similarFeedback = await findSimilarFeedback(query);
        
//         if (similarFeedback.status === "success" && similarFeedback.found) {
//           const botMessage = { 
//             sender: 'bot', 
//             text: `Similar previous interaction found:\nQuery: ${similarFeedback.query}\nResponse: ${similarFeedback.response}\n\n[Similarity: ${(similarFeedback.similarity * 100).toFixed(1)}%]`,
//             mode: activeMode
//           };
//           setChatHistory(prev => [...prev, botMessage]);
//         } else {
//           // Proceed with normal query generation if no similar content found
//           const response = await fetch('http://localhost:5000/api/chat', {
//             method: 'POST',
//             headers: { 'Content-Type': 'application/json' },
//             body: JSON.stringify({
//               message: query,
//               app_functionality: activeMode,
//               sql_dialect: sqlDialect
//             }),
//           });
  
//           const data = await response.json();
          
//           if (!response.ok) throw new Error(data.message || 'Request failed');
          
//           if (data.status === "success") {
//             const botMessage = { 
//               sender: 'bot', 
//               text: data.response || "No response content",
//               mode: activeMode
//             };
//             setChatHistory(prev => [...prev, botMessage]);
//           }
//         }
//       }
//     } catch (error) {
//       setChatHistory(prev => [...prev, { 
//         sender: 'system', 
//         text: `Error: ${error.message}`,
//         mode: activeMode
//       }]);
//     } finally {
//       setIsLoading(false);
//       setQuery("");
//     }
//   };
//   const handleFileUpload = async (e) => {
//     const files = e.target.files;
//     if (!files || files.length === 0 || activeMode !== "File Analysis") return;
    
//     setIsLoading(true);
//     setChatHistory(prev => [...prev, {
//       sender: 'system',
//       text: `Uploading ${files.length} file(s)...`,
//       mode: activeMode
//     }]);

//     try {
//       const formData = new FormData();
//       Array.from(files).forEach(file => formData.append('files', file));

//       const response = await fetch('http://localhost:5000/api/upload', {
//         method: 'POST',
//         body: formData,
//       });

//       if (!response.ok) throw new Error(`Upload failed with status ${response.status}`);
      
//       const data = await response.json();
      
//       if (data.status === "success") {
//         setChatHistory(prev => [
//           ...prev.slice(0, -1),
//           {
//             sender: 'system',
//             text: `Successfully uploaded ${data.files.length} file(s)`,
//             mode: activeMode
//           },
//           ...data.messages.map(msg => ({
//             sender: 'bot',
//             text: msg,
//             mode: activeMode
//           }))
//         ]);
//       } else {
//         throw new Error(data.message || "Upload failed");
//       }
//     } catch (error) {
//       setChatHistory(prev => [
//         ...prev.slice(0, -1),
//         { 
//           sender: 'system', 
//           text: `Upload Error: ${error.message}`,
//           mode: activeMode
//         }
//       ]);
//     } finally {
//       setIsLoading(false);
//       e.target.value = '';
//     }
//   };

//   const clearAll = () => {
//     setQuery("");
//     setChatHistory([]);
//   };

//   const copyToClipboard = (text) => {
//     navigator.clipboard.writeText(text);
//     alert("Copied to clipboard!");
//   };

//   return (
//     <div className="home-container">
//       <div className="chat-container">
//         <div className="mode-selector">
//           <button
//             className={`mode-btn ${activeMode === "SQL Chat" ? "active" : ""}`}
//             onClick={() => {
//               setActiveMode("SQL Chat");
//               setShowIde(false);
//             }}
//           >
//             <FaDatabase className="mode-icon" /> SQL Chat
//           </button>
//           <button
//             className={`mode-btn ${activeMode === "File Analysis" ? "active" : ""}`}
//             onClick={() => {
//               setActiveMode("File Analysis");
//               setShowIde(false);
//             }}
//           >
//             <FaFileAlt className="mode-icon" /> File Analysis
//           </button>
//           <button
//             className={`mode-btn ${showIde ? "active" : ""}`}
//             onClick={() => {
//               setShowIde(!showIde);
//               if (showIde) setActiveMode("SQL Chat");
//             }}
//           >
//             <FaCode className="mode-icon" /> SQL IDE
//           </button>
//         </div>

//         <div className="chat-output">
//           {chatHistory.length === 0 ? (
//             <div className="empty-state">
//               <h3>Welcome to AskQL</h3>
//               <p>Select a mode and start chatting!</p>
//             </div>
//           ) : (
//             chatHistory.map((msg, i) => (
//               <div key={i} className={`chat-message ${msg.sender}`}>
//                 <div className="message-content">
//                   <div className="message-header">
//                     <span className="message-sender">
//                       {msg.sender === 'user' ? 'You' : 
//                        msg.sender === 'bot' ? 'AskQL' : 'System'}
//                     </span>
//                     <span className="message-mode">{msg.mode}</span>
//                   </div>
//                   <div className="message-body">
//                     {msg.sender === 'bot' ? (
//                       <pre>{msg.text}</pre>
//                     ) : (
//                       msg.text
//                     )}
//                   </div>
//                   {msg.sender === 'bot' && (
//                     <>
//                       <button 
//                         className="copy-btn"
//                         onClick={() => copyToClipboard(msg.text)}
//                       >
//                         <FaCopy /> Copy
//                       </button>
//                       <button 
//                         className="execute-btn"
//                         onClick={() => handleExecuteClick(msg.text)}
//                         style={{ marginLeft: '8px' }}
//                       >
//                         <FaPlay /> Execute
//                       </button>
//                       <Feedback 
//                         query={chatHistory[i-1]?.text || ''} 
//                         response={msg.text}
//                         onFeedback={(isCorrect) => handleFeedback(
//                           isCorrect, 
//                           chatHistory[i-1]?.text || '', 
//                           msg.text
//                         )} 
//                       />
//                     </>
//                   )}
//                 </div>
//               </div>
//             ))
//           )}
//           <div ref={chatEndRef} />
//         </div>

//         {showIde ? (
//           // In the SqlIde component usage, change the isDisabled prop:
//           <SqlIde 
//             onExecuteQuery={executeQuery} 
//             isDisabled={false} // Always enable IDE when shown
//             initialQuery={ideQuery}
//           />
//         ) : (
//           <div className="input-section">
//             <div className="input-row">
//               <select
//                 className="sql-dropdown"
//                 value={sqlDialect}
//                 onChange={(e) => setSqlDialect(e.target.value)}
//                 disabled={isLoading}
//               >
//                 <option value="Standard">Standard SQL</option>
//                 <option value="Spark">Spark SQL</option>
//                 <option value="Trino">Trino SQL</option>
//               </select>
//             </div>

//             <div className="input-row">
//               <textarea
//                 className="query-input"
//                 value={query}
//                 onChange={(e) => setQuery(e.target.value)}
//                 placeholder={
//                   activeMode === "SQL Chat" 
//                     ? "Ask me anything about SQL..." 
//                     : "Ask me to analyze your files..."
//                 }
//                 disabled={isLoading}
//                 onKeyDown={(e) => {
//                   if (e.key === "Enter" && !e.shiftKey) {
//                     e.preventDefault();
//                     handleSendMessage();
//                   }
//                 }}
//               />
//             </div>

//             <div className="action-buttons">
//               <div className="file-upload-container">
//                 <label className={`upload-label ${activeMode !== "File Analysis" ? "disabled" : ""}`}>
//                   <FaFileUpload className="upload-icon" />
//                   <span>Upload Files</span>
//                   <input 
//                     type="file" 
//                     multiple 
//                     onChange={handleFileUpload}
//                     accept=".csv,.xlsx"
//                     disabled={isLoading || activeMode !== "File Analysis"}
//                     style={{ display: 'none' }}
//                   />
//                 </label>
//               </div>
              
//               <div className="button-group">
//                 <button 
//                   className="clear-btn" 
//                   onClick={clearAll}
//                   disabled={isLoading}
//                 >
//                   <FaTrash /> Clear
//                 </button>
//                 <button 
//                   className="generate-btn" 
//                   onClick={handleSendMessage}
//                   disabled={isLoading || !query.trim()}
//                 >
//                   {isLoading ? "Processing..." : "Send"}
//                 </button>
//               </div>
//             </div>
//           </div>
//         )}
//       </div>
//     </div>
//   );
// };

// export default Home;



import React, { useState, useRef, useEffect } from "react";
import { FaCopy, FaFileUpload, FaDatabase, FaFileAlt, FaTrash, FaCode, FaPlay } from "react-icons/fa";
import "./Home.css";
import SqlIde from './SqlIde';
import Feedback from './Feedback';

const Home = ({ onBack }) => {
  const [query, setQuery] = useState("");
  const [sqlDialect, setSqlDialect] = useState("Standard");
  const [chatHistory, setChatHistory] = useState([]);
  const [isLoading, setIsLoading] = useState(false);
  const [activeMode, setActiveMode] = useState("SQL Chat");
  const [showIde, setShowIde] = useState(false);
  const [feedbackData, setFeedbackData] = useState([]);
  const [ideQuery, setIdeQuery] = useState("");
  const chatEndRef = useRef(null);

  useEffect(() => {
    scrollToBottom();
  }, [chatHistory]);

  const scrollToBottom = () => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  const handleExecuteClick = (queryText) => {
    const sqlMatch = queryText.match(/SQL Query:\n([\s\S]*?)(?=\n\nExplanation:|$)/) || 
                    queryText.match(/```sql\n([\s\S]*?)\n```/);
    const queryToExecute = sqlMatch ? sqlMatch[1].trim() : queryText;
    
    setIdeQuery(queryToExecute);
    setActiveMode("SQL Chat");
    setShowIde(true);
  };

  const findSimilarFeedback = async (prompt) => {
    try {
      const response = await fetch('http://localhost:5000/api/find-similar-feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: prompt,
          threshold: 0.85
        }),
      });
      return await response.json();
    } catch (error) {
      console.error('Similarity search failed:', error);
      return { status: "error" };
    }
  };

  const handleFeedback = async (isCorrect, prompt, response) => {
    const feedbackItem = {
      query: prompt,
      response: response,
      isCorrect,
      timestamp: new Date().toISOString()
    };
    
    setFeedbackData(prev => [...prev, feedbackItem]);
    
    try {
      await fetch('http://localhost:5000/api/feedback', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(feedbackItem),
      });
  
      if (isCorrect && activeMode === "SQL Chat") {
        await fetch('http://localhost:5000/api/store-approved-query', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            prompt: prompt,
            sql_query: response
          }),
        });
      }
  
      if (!isCorrect) {
        setIsLoading(true);
        
        // Modified to include feedback in the request
        const regenResponse = await fetch('http://localhost:5000/api/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            message: prompt,
            app_functionality: activeMode,
            sql_dialect: sqlDialect,
            feedback: "no" // Add feedback parameter
          }),
        });
        
        const regenData = await regenResponse.json();
        
        if (regenData.status === "success") {
          const botMessage = { 
            sender: 'bot', 
            text: `Revised Query:\n${regenData.response}`,
            mode: activeMode
          };
          setChatHistory(prev => [...prev, botMessage]);
        }
      }
    } catch (error) {
      console.error('Feedback error:', error);
      setChatHistory(prev => [...prev, {
        sender: 'system',
        text: `Error: ${error.message}`,
        mode: activeMode
      }]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const executeQuery = async (query) => {
    try {
      const response = await fetch('http://localhost:5000/api/execute-sql', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ query }),
      });
      const data = await response.json();
      if (data.status === "success") {
        return data.results || [];
      }
      throw new Error(data.message || "Query execution failed");
    } catch (error) {
      setChatHistory(prev => [...prev, {
        sender: 'system',
        text: `SQL Error: ${error.message}`,
        mode: activeMode
      }]);
      return [];
    }
  };

  const findSimilarQuery = async (prompt) => {
    try {
      const response = await fetch('http://localhost:5000/api/find-similar-query', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ 
          prompt: prompt,
          threshold: 0.85
        }),
      });
      return await response.json();
    } catch (error) {
      console.error('Similarity search failed:', error);
      return { status: "error" };
    }
  };

  const handleSendMessage = async () => {
    if (!query.trim()) return;
    
    setIsLoading(true);
    const userMessage = { sender: 'user', text: query, mode: activeMode };
    setChatHistory(prev => [...prev, userMessage]);
    
    try {
      const similarQuery = await findSimilarQuery(query);
      
      if (similarQuery.status === "success" && similarQuery.found) {
        const botMessage = { 
          sender: 'bot', 
          text: `Similar approved query found:\n${similarQuery.sql_query}\n\n[Similarity: ${(similarQuery.similarity * 100).toFixed(1)}%]`,
          mode: activeMode
        };
        setChatHistory(prev => [...prev, botMessage]);
      } else {
        const similarFeedback = await findSimilarFeedback(query);
        
        if (similarFeedback.status === "success" && similarFeedback.found) {
          const botMessage = { 
            sender: 'bot', 
            text: `Similar previous interaction found:\nQuery: ${similarFeedback.query}\nResponse: ${similarFeedback.response}\n\n[Similarity: ${(similarFeedback.similarity * 100).toFixed(1)}%]`,
            mode: activeMode
          };
          setChatHistory(prev => [...prev, botMessage]);
        } else {
          const response = await fetch('http://localhost:5000/api/chat', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
              message: query,
              app_functionality: activeMode,
              sql_dialect: sqlDialect
            }),
          });
  
          const data = await response.json();
          
          if (!response.ok) throw new Error(data.message || 'Request failed');
          
          if (data.status === "success") {
            const botMessage = { 
              sender: 'bot', 
              text: data.response || "No response content",
              mode: activeMode
            };
            setChatHistory(prev => [...prev, botMessage]);
          }
        }
      }
    } catch (error) {
      setChatHistory(prev => [...prev, { 
        sender: 'system', 
        text: `Error: ${error.message}`,
        mode: activeMode
      }]);
    } finally {
      setIsLoading(false);
      setQuery("");
    }
  };

  const handleFileUpload = async (e) => {
    const files = e.target.files;
    if (!files || files.length === 0 || activeMode !== "File Analysis") return;
    
    setIsLoading(true);
    setChatHistory(prev => [...prev, {
      sender: 'system',
      text: `Uploading ${files.length} file(s)...`,
      mode: activeMode
    }]);

    try {
      const formData = new FormData();
      Array.from(files).forEach(file => formData.append('files', file));

      const response = await fetch('http://localhost:5000/api/upload', {
        method: 'POST',
        body: formData,
      });

      if (!response.ok) throw new Error(`Upload failed with status ${response.status}`);
      
      const data = await response.json();
      
      if (data.status === "success") {
        setChatHistory(prev => [
          ...prev.slice(0, -1),
          {
            sender: 'system',
            text: `Successfully uploaded ${data.files.length} file(s)`,
            mode: activeMode
          },
          ...data.messages.map(msg => ({
            sender: 'bot',
            text: msg,
            mode: activeMode
          }))
        ]);
      } else {
        throw new Error(data.message || "Upload failed");
      }
    } catch (error) {
      setChatHistory(prev => [
        ...prev.slice(0, -1),
        { 
          sender: 'system', 
          text: `Upload Error: ${error.message}`,
          mode: activeMode
        }
      ]);
    } finally {
      setIsLoading(false);
      e.target.value = '';
    }
  };

  const clearAll = () => {
    setQuery("");
    setChatHistory([]);
  };

  const copyToClipboard = (text) => {
    navigator.clipboard.writeText(text);
    alert("Copied to clipboard!");
  };

  const isSQLOutput = (text) => {
    return text.includes("SQL Query:") || text.includes("```sql") || 
           text.match(/SELECT\s.+?\sFROM/i) || 
           text.match(/INSERT\s.+?\sINTO/i) || 
           text.match(/UPDATE\s.+?\sSET/i) || 
           text.match(/DELETE\s.+?\sFROM/i);
  };

  return (
    <div className="home-container">
      <div className="chat-container">
        <div className="mode-selector">
          <button
            className={`mode-btn ${activeMode === "SQL Chat" ? "active" : ""}`}
            onClick={() => {
              setActiveMode("SQL Chat");
              setShowIde(false);
            }}
          >
            <FaDatabase className="mode-icon" /> SQL Chat
          </button>
          <button
            className={`mode-btn ${activeMode === "File Analysis" ? "active" : ""}`}
            onClick={() => {
              setActiveMode("File Analysis");
              setShowIde(false);
            }}
          >
            <FaFileAlt className="mode-icon" /> File Analysis
          </button>
          <button
            className={`mode-btn ${showIde ? "active" : ""}`}
            onClick={() => {
              setShowIde(!showIde);
              if (showIde) setActiveMode("SQL Chat");
            }}
          >
            <FaCode className="mode-icon" /> SQL IDE
          </button>
        </div>

        <div className="chat-output">
          {chatHistory.length === 0 ? (
            <div className="empty-state">
              <h3>Welcome to AskQL</h3>
              <p>Select a mode and start chatting!</p>
            </div>
          ) : (
            chatHistory.map((msg, i) => (
              <div key={i} className={`chat-message ${msg.sender}`}>
                <div className="message-content">
                  <div className="message-header">
                    <span className="message-sender">
                      {msg.sender === 'user' ? 'You' : 
                       msg.sender === 'bot' ? 'AskQL' : 'System'}
                    </span>
                    <span className="message-mode">{msg.mode}</span>
                  </div>
                  <div className="message-body">
                    {msg.sender === 'bot' ? (
                      <pre>{msg.text}</pre>
                    ) : (
                      msg.text
                    )}
                  </div>
                  {msg.sender === 'bot' && isSQLOutput(msg.text) && (
                    <>
                      <button 
                        className="copy-btn"
                        onClick={() => copyToClipboard(msg.text)}
                      >
                        <FaCopy /> Copy
                      </button>
                      <button 
                        className="execute-btn"
                        onClick={() => handleExecuteClick(msg.text)}
                        style={{ marginLeft: '8px' }}
                      >
                        <FaPlay /> Execute
                      </button>
                    </>
                  )}
                  {msg.sender === 'bot' && (
                    <Feedback 
                      query={chatHistory[i-1]?.text || ''} 
                      response={msg.text}
                      onFeedback={(isCorrect) => handleFeedback(
                        isCorrect, 
                        chatHistory[i-1]?.text || '', 
                        msg.text
                      )} 
                    />
                  )}
                </div>
              </div>
            ))
          )}
          <div ref={chatEndRef} />
        </div>

        {showIde ? (
          <SqlIde 
            onExecuteQuery={executeQuery} 
            isDisabled={false}
            initialQuery={ideQuery}
          />
        ) : (
          <div className="input-section">
            <div className="input-row">
              <select
                className="sql-dropdown"
                value={sqlDialect}
                onChange={(e) => setSqlDialect(e.target.value)}
                disabled={isLoading}
              >
                <option value="Standard">Standard SQL</option>
                <option value="Spark">Spark SQL</option>
                <option value="Trino">Trino SQL</option>
              </select>
            </div>

            <div className="input-row">
              <textarea
                className="query-input"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder={
                  activeMode === "SQL Chat" 
                    ? "Ask me anything about SQL..." 
                    : "Ask me to analyze your files..."
                }
                disabled={isLoading}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && !e.shiftKey) {
                    e.preventDefault();
                    handleSendMessage();
                  }
                }}
              />
            </div>

            <div className="action-buttons">
              <div className="file-upload-container">
                <label className={`upload-label ${activeMode !== "File Analysis" ? "disabled" : ""}`}>
                  <FaFileUpload className="upload-icon" />
                  <span>Upload Files</span>
                  <input 
                    type="file" 
                    multiple 
                    onChange={handleFileUpload}
                    accept=".csv,.xlsx"
                    disabled={isLoading || activeMode !== "File Analysis"}
                    style={{ display: 'none' }}
                  />
                </label>
              </div>
              
              <div className="button-group">
                <button 
                  className="clear-btn" 
                  onClick={clearAll}
                  disabled={isLoading}
                >
                  <FaTrash /> Clear
                </button>
                <button 
                  className="generate-btn" 
                  onClick={handleSendMessage}
                  disabled={isLoading || !query.trim()}
                >
                  {isLoading ? "Processing..." : "Send"}
                </button>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Home;