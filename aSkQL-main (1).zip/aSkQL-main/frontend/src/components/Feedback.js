import React from 'react';
import { FaThumbsUp, FaThumbsDown } from 'react-icons/fa';
import './Feedback.css';

const Feedback = ({ query, response, onFeedback }) => {
  const handleFeedback = (isCorrect) => {
    // Pass all three parameters to the handler
    onFeedback(isCorrect, query, response);
  };

  return (
    <div className="feedback-container">
      <p>Was this response helpful?</p>
      <div className="feedback-buttons">
        <button onClick={() => handleFeedback(true)}>
          <FaThumbsUp /> Yes
        </button>
        <button onClick={() => handleFeedback(false)}>
          <FaThumbsDown /> No
        </button>
      </div>
    </div>
  );
};

export default Feedback;