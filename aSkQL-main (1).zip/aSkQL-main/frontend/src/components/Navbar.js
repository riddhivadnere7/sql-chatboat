import React from "react";
import { FaUser, FaSignInAlt, FaHome } from "react-icons/fa";
import './Navbar.css';
import logo from '../assets/askql-logo.png';

const Navbar = ({ setCurrentPage }) => {
  return (
    <header className="askql-navbar">
      <div className="navbar-brand">
        <button 
          onClick={() => setCurrentPage('homepage')} 
          className="brand-link"
          style={{ background: 'none', border: 'none', cursor: 'pointer' }}
        >
          <div className="logo-title-container">
            <img 
              src={logo} 
              alt="AskQL Logo" 
              className="navbar-logo"
            /> 
            <h1>AskQL:<span>TEXT TO SQL GENERATOR</span></h1>
          </div>
        </button>
      </div>

      <nav className="navbar-links">
        <button 
          onClick={() => setCurrentPage('sql-generator')} 
          className="nav-link"
        >
          <FaHome className="nav-icon" />
          SQL Generator
        </button>


        <div className="nav-dropdown">
          <button className="nav-link">
            <span className="nav-icon">+</span> Legal
          </button>
          <div className="dropdown-content">
            <a href="#">Explanation</a>
            <a href="#">Output</a>
            <a href="#">Page</a>
          </div>
        </div>

        {/* Auth links */}
        <div className="nav-auth">
          <a href="#" className="auth-link">
            <FaUser className="auth-icon" /> Sign Up
          </a>
          <span className="auth-divider">|</span>
          <a href="#" className="auth-link">
            <FaSignInAlt className="auth-icon" /> Login
          </a>
        </div>
      </nav>
    </header>
  );
};

export default Navbar;