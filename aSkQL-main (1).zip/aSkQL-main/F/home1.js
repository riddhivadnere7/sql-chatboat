document.addEventListener('DOMContentLoaded', function() {
    const sqlTypeSelect = document.getElementById('sqlType');
    const queryInput = document.getElementById('queryInput');
    const generateBtn = document.getElementById('generateBtn');
    const clearBtn = document.getElementById('clearBtn');
    const sqlOutput = document.getElementById('sqlOutput');
    const copyBtn = document.getElementById('copyBtn');
    const backButton = document.getElementById('backButton');
    const outputPre = sqlOutput.querySelector('pre');

    // Generate button click handler
    generateBtn.addEventListener('click', function() {
        const text = queryInput.value.trim();
        const sqlType = sqlTypeSelect.value;
        
        if (!text) {
            outputPre.textContent = 'Please enter a query first';
            copyBtn.style.display = 'none';
            return;
        }
        
        // Simple SQL generation logic
        const generatedSQL = `-- ${sqlType} Query\nSELECT * FROM ${text.toLowerCase().replace(/\s+/g, '_')};\n-- Generated from: "${text}"`;
        outputPre.textContent = generatedSQL;
        copyBtn.style.display = 'block';
    });

    // Clear button click handler
    clearBtn.addEventListener('click', function() {
        queryInput.value = '';
        outputPre.textContent = 'Your SQL will appear here after generation';
        copyBtn.style.display = 'none';
    });

    // Copy button click handler
    copyBtn.addEventListener('click', function() {
        navigator.clipboard.writeText(outputPre.textContent)
            .then(() => {
                const originalIcon = copyBtn.innerHTML;
                copyBtn.innerHTML = '<i class="fas fa-check"></i>';
                setTimeout(() => {
                    copyBtn.innerHTML = originalIcon;
                }, 2000);
            })
            .catch(err => {
                console.error('Failed to copy text: ', err);
            });
    });

    // Back button click handler
    backButton.addEventListener('click', function() {
        alert('Back to home functionality would go here');
        // In a real app, this would navigate back to the main page
        // window.location.href = '/';
    });
});